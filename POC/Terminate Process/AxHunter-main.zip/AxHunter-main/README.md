# AxHunter

PoCs for Wellbia XIGNCODE3 anti-cheat `xhunter` driver family — `xhunter1.sys` v2023.12.7.78 ([CVE-2026-3609](https://www.cve.org/CVERecord?id=CVE-2026-3609)) and `xhunter2.sys` v2026.6.1.192 ([CVE-2026-15430](https://www.cve.org/CVERecord?id=CVE-2026-15430)).

## Workspace layout

Cargo workspace, three crates:

```
AxHunter/
├── Cargo.toml               workspace manifest
├── axhunter-lsa/            shared crate — driver-agnostic LSA extraction (MemReader trait,
│                              LDR walk, BCrypt 3DES key extraction, LogonSessionList,
│                              WDigest). Consumed by both PoCs.
├── axhunter_v1/             xhunter1.sys v2023.12.7.78  (CVE-2026-3609)
└── axhunter_v2/             xhunter2.sys v2026.6.1.192  (CVE-2026-15430)
```

Each PoC crate carries its own target driver binary (`xhunter1.sys`, `xhunter2.sys`) and — in `axhunter_v2/src/` — Wellbia's WBMF module (`wbmf_module.dll`) extracted from a live `WindSlayer.exe` process.

## Build

From the workspace root:

```
cargo build --release              # builds both binaries + shared crate
cargo build --release -p AxHunter_v1
cargo build --release -p AxHunter_v2
```

Both binaries land in `target/release/`:

```
target/release/AxHunter_v1.exe
target/release/AxHunter_v2.exe
```

## Unified CLI

Both binaries share the same flags:

```
AxHunter_v1.exe -m {dump|kill|lpe|inject|all} [-t <pid|image>] [-d <device>] [-p <payload.bin>]
AxHunter_v2.exe -m {dump|kill|lpe|inject|all} [-t <pid|image>] [-d <device>] [-p <payload.bin>]
```

See each crate's README for driver-specific defaults and mode details.

## Companion write-ups

- **[Hunting the Hunter](https://blacksnufkin.github.io/posts/Hunting-the-Hunter/)** — `xhunter1.sys` v2023.12.7.78. Corresponds to `axhunter_v1/`.
- **[Hunting the Hunter II](https://blacksnufkin.github.io/posts/Hunting-the-Hunter-II/)** — `xhunter2.sys` v2026.6.1.192. Corresponds to `axhunter_v2/`.

## Comparison

| Property | `xhunter1.sys` v2023.12.7.78 | `xhunter2.sys` v2026.6.1.192 |
|---|---|---|
| CVE | [CVE-2026-3609](https://www.cve.org/CVERecord?id=CVE-2026-3609) | [CVE-2026-15430](https://www.cve.org/CVERecord?id=CVE-2026-15430) |
| Transport | `IRP_MJ_WRITE`, 624-byte plaintext frame | `IRP_MJ_WRITE`, 1184-byte LCG-XOR-encrypted frame |
| Frame magic | `0x345821AB` | `0x70506202` (`MAGIC ^ SEED_KEY`) |
| Device open auth | None | WBMF RSA-2048 signed PE + Win32StartAddress in-PE |
| Per-request auth | None | WBCC blob + certificate chain iterator |
| PID gate escalation | cmd 777 + cmd 775 | cmd 777 + cmd 779 + cmd 775 |
| cmd 785 (PPL handle mint) | `ObOpenObjectByPointer(KernelMode)` | identical |
| cmd 787 (cross-process read) | `KeStackAttachProcess` byte copy | identical |
| cmd 800 (handle stomp kill) | `KeStackAttachProcess` + `ObSetHandleAttributes(KernelMode)` + `ZwClose` | identical |
| cmd 820 (kernel injection) | RWX alloc + copy + `RtlCreateUserThread` (all ring 0) | identical |

## Sibling reference

- **[CVE-2026-3609](https://www.cve.org/CVERecord?id=CVE-2026-3609)** — `xhunter1.sys` v10.0.10011.16384 through v2023.12.7.78 ([write-up](https://blacksnufkin.github.io/posts/AntiCheat-LPE-CVE-2026-3609/), legacy PoC at [CredsHunter](https://github.com/BlackSnufkin/CredsHunter)).

## License

MIT. See [LICENSE](LICENSE).
