//! Small Windows system helpers that don't fit elsewhere.

use windows::{
    core::s,
    Win32::System::LibraryLoader::{GetModuleHandleA, GetProcAddress},
};

/// Returns the OS build number via `RtlGetNtVersionNumbers`.
pub fn build_number() -> Result<u32, String> {
    type RtlGetNtVersionNumbersFn = unsafe extern "system" fn(*mut u32, *mut u32, *mut u32);

    unsafe {
        let ntdll = GetModuleHandleA(s!("ntdll.dll"))
            .map_err(|e| format!("GetModuleHandleA(ntdll): {e}"))?;
        let func = GetProcAddress(ntdll, s!("RtlGetNtVersionNumbers"))
            .ok_or_else(|| "RtlGetNtVersionNumbers not exported".to_string())?;
        let f: RtlGetNtVersionNumbersFn = std::mem::transmute(func);

        let (mut maj, mut min, mut build) = (0u32, 0u32, 0u32);
        f(&mut maj, &mut min, &mut build);
        Ok(build & 0x7FFF)
    }
}
