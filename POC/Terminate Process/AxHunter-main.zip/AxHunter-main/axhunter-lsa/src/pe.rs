//! Tiny PE helper: locate a module's `.text` section bytes locally, then
//! pattern-scan for a signature. Used to recover RIP-relative references
//! to LSA crypto material inside `lsasrv.dll` / `wdigest.dll`.

use windows::{
    core::PCSTR,
    Win32::System::LibraryLoader::{GetModuleHandleA, LoadLibraryA},
};

/// Ensure `module` is mapped into this process so we can read its bytes.
pub fn ensure_loaded(module: &str) -> Result<(), String> {
    let c = std::ffi::CString::new(module)
        .map_err(|_| format!("invalid module name: {module}"))?;
    unsafe {
        LoadLibraryA(PCSTR(c.as_ptr() as _))
            .map(|_| ())
            .map_err(|e| format!("LoadLibraryA({module}): {e}"))
    }
}

/// Returns the in-process base VA of `module`. Module must already be loaded.
pub fn local_base(module: &str) -> Result<u64, String> {
    let c = std::ffi::CString::new(module)
        .map_err(|_| format!("invalid module name: {module}"))?;
    let h = unsafe { GetModuleHandleA(PCSTR(c.as_ptr() as _)) }
        .map_err(|e| format!("GetModuleHandleA({module}): {e}"))?;
    Ok(h.0 as u64)
}

/// Returns a slice over a module's primary code section in our address space.
pub fn text_section<'a>(module_base: u64) -> Result<&'a [u8], String> {
    unsafe {
        let base = module_base as usize;
        let dos = std::slice::from_raw_parts(base as *const u8, 0x40);
        if dos[0] != b'M' || dos[1] != b'Z' {
            return Err("module base is not an MZ image".into());
        }
        let lfanew = u32::from_le_bytes(dos[0x3C..0x40].try_into().unwrap()) as usize;
        let nt = base + lfanew;
        // OptionalHeader fields:
        //   +0x1C = SizeOfCode
        //   +0x2C = BaseOfCode (.text RVA)
        let code_off = u32::from_le_bytes(*((nt + 0x2C) as *const [u8; 4])) as usize;
        let code_sz  = u32::from_le_bytes(*((nt + 0x1C) as *const [u8; 4])) as usize;
        Ok(std::slice::from_raw_parts((base + code_off) as *const u8, code_sz))
    }
}

/// First-match byte-pattern search. Returns the byte offset within `buf`
/// or `None`.
pub fn find_pattern(buf: &[u8], sig: &[u8]) -> Option<usize> {
    if sig.is_empty() || sig.len() > buf.len() { return None; }
    buf.windows(sig.len()).position(|w| w == sig)
}

/// Decode a 4-byte RIP-relative displacement read at `ptr`. Returns the
/// absolute target VA. `ptr` must point to the first byte of the disp32
/// field — i.e. the instruction's `[rip+disp32]` target operand.
///
/// # Safety
/// Caller guarantees that `ptr..ptr+4` is readable and that the surrounding
/// instruction is RIP-relative with a standard 4-byte displacement.
pub unsafe fn decode_rip_relative(ptr: *const u8) -> u64 {
    let disp = u32::from_le_bytes(*(ptr as *const [u8; 4]));
    (ptr as u64).wrapping_add(disp as u64).wrapping_add(4)
}
