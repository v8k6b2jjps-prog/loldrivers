# axhunter-lsa

Driver-agnostic LSA credential-extraction crate. Shared by [`AxHunter_v1`](../axhunter_v1/) and [`AxHunter_v2`](../axhunter_v2/).

## What it does

Everything above the driver seam:

- **LDR module walk** in a target process, given a `MemReader` implementation.
- **BCrypt 3DES key + IV extraction** from `lsasrv.dll` per Windows build (offset table).
- **`LogonSessionList` walk + decrypt** — NT hashes, SHA1 hashes.
- **WDigest walk + decrypt** — plaintext passwords (when `UseLogonCredential` is set).
- Minimal PE / OS-build / module-base helpers used by the above.

## The seam

One trait:

```rust
pub trait MemReader {
    fn read(&self, addr: u64, buf: &mut [u8]) -> bool;
    // default helpers: read_u32, read_u64, read_bytes, read_unicode_string
}
```

Consumers implement it however they get memory access:

- **AxHunter v1** — `ReadProcessMemory` against the cmd-785 kernel-minted handle, with cmd 787 driver-side byte-copy as a fallback.
- **AxHunter v2** — cmd 787 (`KeStackAttachProcess` + byte copy) exclusively.

Both are wired in the consuming crate's `Session` / `Xh2Session` struct. Nothing in `axhunter-lsa` knows or cares which driver produced the reads.

## Layout

```
axhunter-lsa/
├── Cargo.toml
└── src/
    ├── lib.rs        MemReader trait definition + module re-exports
    ├── pe.rs         local-process module base lookup
    ├── sys.rs        RtlGetNtVersionNumbers → OS build number
    ├── lsa.rs        BCrypt 3DES key + IV extraction from lsasrv.dll
    ├── logon.rs      LogonSessionList walk + decrypt (NT/SHA1 hashes)
    └── wdigest.rs    WDigest list walk + decrypt (plaintext)
```

## Not published to crates.io

Path-only dependency inside the workspace. Not intended for standalone use — the credential-extraction offsets are only valid against the specific Windows builds AxHunter targets, and the shape of `MemReader` follows what the two AxHunter drivers can actually do.
