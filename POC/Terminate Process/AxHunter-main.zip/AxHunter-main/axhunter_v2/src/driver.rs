// `MemReader` trait moved to shared crate `axhunter-lsa`.
// Re-exported here so downstream call sites can keep the local import path.
pub use axhunter_lsa::MemReader;
