//! Process enumeration + PEB-walk module discovery.
//!
//! `find_pid` walks the toolhelp32 snapshot to resolve a target's PID.
//! `find_remote_module` uses the driver session to walk the target's
//! PEB → PEB_LDR_DATA → InMemoryOrderModuleList and resolve a remote
//! module's base address by name.

use std::ffi::c_void;

use windows::{
    core::s,
    Win32::{
        Foundation::{CloseHandle, HANDLE},
        System::{
            Diagnostics::ToolHelp::{
                CreateToolhelp32Snapshot, Process32FirstW, Process32NextW,
                PROCESSENTRY32W, TH32CS_SNAPPROCESS,
            },
            LibraryLoader::{GetModuleHandleA, GetProcAddress},
        },
    },
};

use crate::driver::{MemReader, Session};

/// Find a process by image name (case-insensitive). Returns its PID.
pub fn find_pid(image_name: &str) -> Result<u32, String> {
    let target = image_name.to_ascii_lowercase();

    unsafe {
        let snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
            .map_err(|e| format!("CreateToolhelp32Snapshot: {e}"))?;

        let mut entry = PROCESSENTRY32W {
            dwSize: std::mem::size_of::<PROCESSENTRY32W>() as u32,
            ..Default::default()
        };

        if Process32FirstW(snap, &mut entry).is_ok() {
            loop {
                let end = entry.szExeFile.iter()
                    .position(|&c| c == 0)
                    .unwrap_or(entry.szExeFile.len());
                let name = String::from_utf16_lossy(&entry.szExeFile[..end]).to_ascii_lowercase();
                if name == target {
                    let _ = CloseHandle(snap);
                    return Ok(entry.th32ProcessID);
                }
                if Process32NextW(snap, &mut entry).is_err() { break; }
            }
        }

        let _ = CloseHandle(snap);
    }

    Err(format!("process '{image_name}' not found"))
}

/// Walk the target process's PEB to find a loaded module's base address.
/// Uses `NtQueryInformationProcess(ProcessBasicInformation)` to obtain the
/// PEB pointer (the handle was minted in kernel mode and has full access).
pub fn find_remote_module(session: &Session<'_>, module_name: &str) -> Result<u64, String> {
    let peb_va = peb_address(session.handle())?;
    let ldr = session.read_u64(peb_va + 0x18);   // PEB.Ldr
    if ldr == 0 { return Err("PEB.Ldr is NULL".into()); }

    // PEB_LDR_DATA.InMemoryOrderModuleList = +0x20.
    let list_head = ldr + 0x20;
    let target = module_name.to_ascii_lowercase();
    let mut flink = session.read_u64(list_head);

    for _ in 0..256 {
        if flink == 0 || flink == list_head { break; }
        let dll_base = session.read_u64(flink + 0x20);
        let name = session.read_unicode_string(flink + 0x48);
        if name.to_ascii_lowercase() == target {
            return Ok(dll_base);
        }
        let next = session.read_u64(flink);
        if next == flink { break; }
        flink = next;
    }

    Err(format!("module '{module_name}' not found in target"))
}

// ─── private ────────────────────────────────────────────────────────────────

type NtQipFn = unsafe extern "system" fn(HANDLE, u32, *mut c_void, u32, *mut u32) -> i32;

fn peb_address(process: HANDLE) -> Result<u64, String> {
    unsafe {
        let ntdll = GetModuleHandleA(s!("ntdll.dll"))
            .map_err(|e| format!("GetModuleHandleA(ntdll): {e}"))?;
        let proc = GetProcAddress(ntdll, s!("NtQueryInformationProcess"))
            .ok_or_else(|| "NtQueryInformationProcess not exported".to_string())?;
        let nt_qip: NtQipFn = std::mem::transmute(proc);

        // PROCESS_BASIC_INFORMATION: { ExitStatus, PebBaseAddress, AffinityMask, BasePriority, UniquePID, ParentPID }
        let mut pbi = [0u8; 48];
        let mut ret_len = 0u32;
        let status = nt_qip(
            process,
            0, // ProcessBasicInformation
            pbi.as_mut_ptr() as _,
            48,
            &mut ret_len,
        );
        if status != 0 {
            return Err(format!("NtQueryInformationProcess: 0x{:08X}", status as u32));
        }
        Ok(u64::from_le_bytes(pbi[8..16].try_into().unwrap()))
    }
}
